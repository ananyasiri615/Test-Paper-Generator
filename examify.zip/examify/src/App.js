import { React } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";

import AdminLogin from "./components/Admin/AdminLogin.js";
import AdminRegister from "./components/Admin/AdminRegister.js";
import AdminWelcomePage from "./components/Admin/AdminWelcomePage.js";
import CandidateAdmin from "./components/Admin/CandidateAdmin.js";
import QuestionAdmin from "./components/Admin/QuestionAdmin5.js";
import SubjectAdmin from "./components/Admin/SubjectAdmin.js";
import Allsections from "./components/Candidate/Allsections.js";
import InstructionsAccess from "./components/Candidate/InstructionsAccess.js";
import Login from "./components/CandidateLoginAndRegister/Login.js";
import Register from "./components/CandidateLoginAndRegister/Register.js";
import Testpaper from "./components/Candidate/Testpaper.js";
import WelcomePage from "./components/Candidate/WelcomePage.js";
import Navbar from "./components/Common/Navbar.js";
import AdminFdback from "./components/Admin/AdminFdback.js";
import AdminNavBar from "./components/Admin/AdminNavBar.js";
import UpdateQuestion from "./components/Admin/UpdateQuestion.js";
import ViewOneQuestion from "./components/Admin/ViewOneQuestion.js";
import FeedbackForm from "./components/Candidate/FeedbackForm.js";
import Report from "./components/Candidate/Report.js";
import TestPaperHistory from "./components/Candidate/TestPaperHistory.js";
import CommonWelcomePage from "./components/Common/CommonWelcomePage.js";
import VideoDisplay from "./components/Candidate/VideoDisplay.js";
import ViolationPage from "./components/Candidate/Violationpage.js";
import CandidateHistoryTable from "./components/Admin/CandidateHistoryTable.js";
import CandidateNavbar from "./components/Candidate/CandidateNavbar.js";
import ContactUs from "./components/Common/ContactUs.js";
import ContactUsAdmin from "./components/Admin/ContactUsAdmin.js";

const App = () => {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          {/* <Route path="/" element={<WelcomePage />} /> */}
          <Route
            path="/Register"
            element={
              <>
                <Navbar />
                <Register />
              </>
            }
          />
          <Route
            path="/Login"
            element={
              <>
                <Navbar />
                <Login />
              </>
            }
          />

          <Route
            path="/WelcomePage"
            element={
              <>
                <CandidateNavbar />
                <WelcomePage />
              </>
            }
          />
          <Route
            path="/"
            element={
              <>
                <CommonWelcomePage />
              </>
            }
          />
          <Route
            path="/AdminRegister"
            element={
              <>
                <Navbar />
                <AdminRegister />
              </>
            }
          />
          <Route
            path="/AdminLogin"
            element={
              <>
                <Navbar />
                <AdminLogin />
              </>
            }
          />
          <Route
            path="/ContactUs"
            element={
              <>
                <Navbar />
                <ContactUs />
              </>
            }
          />
          <Route path="/InstructionsAccess" element={<InstructionsAccess />} />
          <Route path="/Allsections" element={<Allsections />} />
          <Route path="/Testpaper" element={<Testpaper />} />
          <Route
            path="/Allsections/:cameraPermission/:microphonePermission"
            element={<Allsections />}
          />
          <Route path="/testpaper" component={Testpaper} />
          {/* <Route path="/testreport" component={TestReport} /> */}
          <Route
            path="/Testpaper/:cameraPermission/:microphonePermission"
            element={<Testpaper />}
          />
          <Route path="/FeedbackForm" element={<FeedbackForm />} />
          {/* <Route path="/ResultsPage" element={<ResultsPage />} /> */}
          {/* <Route path="/Allsections" element={<Allsections generateRandomSection={generateRandomSection} />} /> */}
          <Route path="/testpaper" component={Testpaper} />
          <Route
            path="/TestPaperHistory"
            element={
              <>
                <CandidateNavbar />
                <TestPaperHistory />
              </>
            }
          />
          {/* <Route path="/testreport" component={TestReport} /> */}
          <Route path="/ViolationPage" element={<ViolationPage />} />
          <Route
            path="/Report/:totalMarks/:totalTestPaperMarks"
            element={<Report />}
          />
          <Route
            path="/AdminWelcomePage"
            element={
              <>
                <AdminNavBar />
                <AdminWelcomePage />
              </>
            }
          />

          <Route path="/Admin" element={<AdminNavBar />}>
            {/* <Route path="/Admin/WelcomePage" element={<AdminWelcomePage />} /> */}
            <Route
              path="/Admin/ViewOneQuestion"
              element={<ViewOneQuestion />}
            />

            <Route
              path="/Admin/TestPaperHistory"
              element={<CandidateHistoryTable />}
            />
            <Route path="/Admin/ContactUsAdmin" element={<ContactUsAdmin />} />
            <Route path="/Admin/AdminFdback" element={<AdminFdback />} />
            <Route path="/Admin/UpdateQuestion" element={<UpdateQuestion />} />
            <Route path="/Admin/QuestionAdmin" element={<QuestionAdmin />} />
            <Route path="/Admin/SubjectAdmin" element={<SubjectAdmin />} />
            <Route path="/Admin/CandidateAdmin" element={<CandidateAdmin />} />
          </Route>
          {/* <Route path="/Testpaper" element={<Testpaper cameraPermission={cameraPermission} microphonePermission={microphonePermission} />} />
          <Route path="/Allsections" element={<Allsections cameraPermission={cameraPermission} microphonePermission={microphonePermission} />} /> */}
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;
