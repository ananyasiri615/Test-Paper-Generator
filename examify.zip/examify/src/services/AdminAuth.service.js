const login = async (username: string, password: string): Promise<any> => {
    const apiUrl = "http://localhost:8081/authenticate"; 
    const requestData = {
      username,
      password,
    };
  
    return fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestData),
    })
      .then((response) => {
        if (response.ok) {
          return response.json().then((data) => {
            if (data.jwt) {
              console.log(data.jwt)
              localStorage.setItem("user", JSON.stringify(data.jwt));
            }
            return data;
          });
        } else {
          throw new Error("Login failed");
        }
      });
  };
  
const logout = () => {
  localStorage.removeItem("user");
};

const getCurrentUser = () => {
  return JSON.parse(localStorage.getItem("user"));
};

const AdminAuthService = {
  
  login,
  logout,
  getCurrentUser,
};

export default AdminAuthService;