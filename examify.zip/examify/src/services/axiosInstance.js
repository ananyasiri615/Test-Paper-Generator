import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'http://localhost:8081',
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJjYW5kaTEiLCJleHAiOjE2OTc3MDM0MjQsImlhdCI6MTY5NzcwMTYyNH0.8nt2B0PX_O-W0sFKYg7F42iMgaHFhAd2SiewV9-WUrM',
    'Content-Type': 'application/json',
  },
});

export default axiosInstance;
