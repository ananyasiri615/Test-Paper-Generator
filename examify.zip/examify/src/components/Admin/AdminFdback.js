
import React, { useEffect, useState } from 'react';
import { Navigate, useNavigate } from "react-router-dom";
import './AdminFdback.css'; // Import your CSS stylesheet
import { Pie } from 'react-chartjs-2';

function FeedbackList() {
  const [feedbackList, setFeedbackList] = useState([]);
  const [platformRatingsData, setPlatformRatingsData] = useState({});
  const [examRatingsData, setExamRatingsData] = useState({});
  const token = localStorage.getItem("admin")
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:8081/feedback/all')
      .then((response) => response.json())
      .then((data) => {
        setFeedbackList(data);

        // Calculate platform ratings data
        const tmpPlatformRatingsData = data.reduce((acc, feedback) => {
          const rating = feedback.platformratings;
          acc[rating] = (acc[rating] || 0) + 1;
          return acc;
        }, {});

        setPlatformRatingsData(tmpPlatformRatingsData);

        // Calculate exam ratings data
        const tmpExamRatingsData = data.reduce((acc, feedback) => {
          const rating = feedback.examRatings;
          acc[rating] = (acc[rating] || 0) + 1;
          return acc;
        }, {});

        setExamRatingsData(tmpExamRatingsData);
      });
  }, []);

  // Define the data for the platform ratings Pie chart
  const platformRatingsChartData = {
    labels: Object.keys(platformRatingsData),
    datasets: [
      {
        data: Object.values(platformRatingsData),
        backgroundColor: ['red', 'blue', 'green','yellow','orange'], // Define colors for different ratings
      },
    ],
  };
  const examRatingsChartData = {
    labels: Object.keys(examRatingsData),
    datasets: [
      {
        data: Object.values(examRatingsData),
        backgroundColor: ['purple', 'pink', 'cyan', 'magenta', 'teal'],
      },
    ],
  };

  if(!token){
    return <Navigate to = "/AdminLogin"/>
  }
  return (
    <div>
      <h2 className="feedback-header">Feedback Reports</h2>
      <table className="feedback-table">
        <thead>
          <tr>
            <th>Username</th>
            <th>Exam Feedback</th>
            <th>Platform Feedback</th>
            <th>Platform Ratings</th>
            <th>Exam Ratings</th>
          </tr>
        </thead>
        <tbody>
          {feedbackList.map((feedback) => (
            <tr key={feedback.id}>
              <td>{feedback.username}</td>
              <td>{feedback.examFeedback}</td>
              <td>{feedback.platformFeedback}</td>
              <td>{feedback.platformratings}</td>
              <td>{feedback.examRatings}</td>
            </tr>
          ))}
        </tbody>
      </table> <br /> <br /> <br />
      {/* <h3>Platform Ratings</h3>
      <div className="chart-container">
       
        <Pie data={platformRatingsChartData} />
      </div>
      
      <h3>Exam Ratings</h3>
      <div className="chart-container">
        <Pie data={examRatingsChartData} />
      </div> */}
      <div style={{ display: 'flex', justifyContent: 'space-between' ,paddingLeft:"50px"}}>
  <div style={{ flex: 1 }}>
    <h3 style={{paddingLeft:"100px"}}>Platform Ratings</h3>
    <div className="chart-container">
      <Pie data={platformRatingsChartData} />
    </div>
  </div>

  <div style={{ flex: 1 }}>
    <h3 style={{paddingLeft:"100px"}}>Exam Ratings</h3>
    <div className="chart-container">
      <Pie data={examRatingsChartData} />
    </div>
  </div>
</div>

    </div>
  );
}

export default FeedbackList;
