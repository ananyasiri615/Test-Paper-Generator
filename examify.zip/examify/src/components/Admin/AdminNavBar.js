import React, { useState, useEffect } from "react";
import { Link, Outlet, Navigate } from "react-router-dom";

const AdminNavBar = () => {
  const [loginStatus, setLoginStatus] = useState(true);
  const [admin, SetAdmin] = useState('');

  useEffect(() => {
    const storedUsername = localStorage.getItem('admin');
    SetAdmin(storedUsername);
  }, []);

  const handleLogout = () => {
    localStorage.clear();
    setLoginStatus(false);
  };
  if (loginStatus === false) {
    return <Navigate to="/" />;
  }

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <a
          className="navbar-brand"
          href="/AdminWelcomePage"
          style={{ marginLeft: "15px",marginTop:"-4px" }}
        >
          <b style={{fontSize:"20px"}}>Examify </b>
        </a>
        <div className="container-fluid">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item dropdown">
                <a
                  class="nav-link dropdown-toggle"
                  href="#"
                  id="navbarDropdown"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <b style={{Color:"black",fontSize:"15px"}}>Functionalities </b>
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li>
                    <Link className="nav-link" to="/Admin/QuestionAdmin">
                      <b style={{Color:"black"}}>Questions </b>
                    </Link>
                  </li>
                  <li>
                    <Link className="nav-link" to="/Admin/SubjectAdmin">
                      <b style={{Color:"black"}}>Subject</b>
                    </Link>
                  </li>
                  <li>
                    <Link className="nav-link" to="/Admin/AdminFdback">
                      <b style={{Color:"black"}}> View Feed Back </b>
                    </Link>
                  </li>
                  <li>
                    <Link className="nav-link" to="/Admin/TestPaperHistory">
                      <b style={{Color:"black"}}>View Scores</b>
                    </Link>
                  </li>
                </ul>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/Admin/CandidateAdmin">
                  <b style={{Color:"black",fontSize:"15px"}}>Candidate Details</b>
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/Admin/ContactUsAdmin">
                  <b style={{Color:"black",fontSize:"15px"}}>Enquiries</b>
                </Link>
              </li>
              <li className="d-flex" style={{ marginLeft: "750px" }}>
                <button
                  type="button"
                  className="btn btn-light dropdown-item fw-bold"
                  style={{
                    backgroundColor: "black",
                    padding: "8px 12px",
                    border: "1px solid black",
                  }}
                  data-bs-toggle="modal"
                  data-bs-target="#staticBackdrop"
                >
                  <span style={{ color: "white" }}>Logout</span>
                </button>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div
        class="modal fade"
        id="staticBackdrop"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        tabindex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="staticBackdropLabel">
                Logout
              </h1>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">Hello {admin}!!, <br/>
              Are you sure you want to Logout?</div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-outline-success"
                data-bs-dismiss="modal"
              >
                Cancel
              </button>
              <button
                type="button"
                class="btn btn-outline-danger"
                onClick={handleLogout}
                data-bs-dismiss="modal"
              >
                Yes
              </button>
            </div>
          </div>
        </div>
      </div>
      <Outlet />
    </div>
  );
};

export default AdminNavBar;
