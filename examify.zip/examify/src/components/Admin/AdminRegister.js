import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './AdminRegister.css'; // Import the CSS file

const AdminRegister = () => {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [registrationStatus, setRegistrationStatus] = useState('');

  const navigate = useNavigate();

  const [emailError, setEmailError] = useState('');
  const [usernameError, setUsernameError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const isEmailValid = (email) => {
    // Add email validation logic (e.g., using a regular expression)
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    return emailRegex.test(email);
  };

  const isPasswordValid = (password) => {
    const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&!_+=-]).{8,}$/;
    return passwordRegex.test(password);
  };
  

  const isUsernameValid = (username) => {
    // Add username validation logic (e.g., not empty)
    return username.trim() !== '';
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'email') {
      setEmail(value);
    } else if (name === 'username') {
      setUsername(value);
    } else if (name === 'password') {
      setPassword(value);
    }
  };

  const validateForm = () => {
    let valid = true;

    if (!isEmailValid(email)) {
      setEmailError('Invalid email');
      valid = false;
    } else {
      setEmailError('');
    }

    if (!isPasswordValid(password)) {
      setPasswordError('Invalid password');
      valid = false;
    } else {
      setPasswordError('');
    }

    if (!isUsernameValid(username)) {
      setUsernameError('Invalid username');
      valid = false;
    } else {
      setUsernameError('');
    }

    return valid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const isFormValid = validateForm();

    if (!isFormValid) {
      return;
    }

    try {
      // Replace the API endpoint with your actual registration API
      const response = await fetch('http://localhost:8080/api/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, username, password }),
      });

      if (response.ok) {
        // Registration successful
        setRegistrationStatus('Registration successful');
        // Redirect to the success page or any desired page
        navigate('/AdminLogin');
      } else {
        setRegistrationStatus('Error Occurred');
      }
    } catch (error) {
      console.error('Error:', error);
      setRegistrationStatus('Error Occurred');
    }
  };

  const registerhandler =() =>{
    navigate("/AdminLogin");
  }

  return (
    <div className="admin-register-container">
      <div className="adminregister-card" style={{ backgroundImage: `url(${process.env.PUBLIC_URL}/bg.jpg)`, backgroundSize: 'cover' }}>
        <h2 className="card-title text-center" style={{ color: '#007BFF' ,margin:"10px",color:"red"}}>
          Admin Registration
        </h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="email" className="form-label" style={{padding:"3px",marginLeft:"1px"}}>
              Email
            </label>
            <input
              type="email"
              className="form-control"
              placeholder="Email"
              name="email"
              value={email}
              onChange={handleChange}
            />
            {emailError && <p className="error-message">{emailError}</p>}
          </div>
          <div className="mb-3">
            <label htmlFor="username" className="form-label" style={{padding:"3px",marginLeft:"1px"}}>
              Username
            </label>
            <input
              type="text"
              className="form-control"
              placeholder="Username"
              name="username"
              value={username}
              onChange={handleChange}
            />
            {usernameError && <p className="error-message">{usernameError}</p>}
          </div>
          <div className="mb-3">
            <label htmlFor="password" className="form-label" style={{padding:"3px",marginLeft:"1px"}}>
              Password
            </label>
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              name="password"
              value={password}
              onChange={handleChange}
            />
            {passwordError && <p className="error-message">{passwordError}</p>}
          </div>
          <div className="text-center">
            <button type="submit" className="btn btn-primary" onClick={registerhandler}>
              Register
            </button>
            {/* <p className="pb-lg-2 text-center" style={{ color: "#393f81" }}>
            Already have an account? &nbsp;
            <a href="/AdminLogin" style={{ color: "#393f81" }}>
               Login Here
            </a></p> */}
          </div>
          {registrationStatus === 'Error Occurred' && <p className="error-message">Error Occurred</p>}
          {registrationStatus === 'Registration successful' && <p className="success-message">Registration successful</p>}
        </form>
      </div>
      <div className="image-container">
        <img src="online-exam.gif" alt="Register Image" />
      </div>
    </div>
  );
};

export default AdminRegister;