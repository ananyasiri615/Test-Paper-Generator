import React, { useEffect, useState } from "react";
import axios from "axios";
import { useLocation, useNavigate, Navigate } from "react-router-dom";

const ViewOneQuestion = () => {
  const [questions, setQuestions] = useState({});
  const location = useLocation();
  const { q_id } = location.state;
  const token = localStorage.getItem("admin")
  const navigate = useNavigate();

  const getQuestion = (q_id) => {
    axios
      .get(`http://localhost:8081/questions/id/${q_id}`)
      .then((response) => {
        if (response.data) {
          setQuestions(response.data);
        } else {
          console.log("not found");
        }
      })
      .catch((err) => console.log(err));
  };
  const handleQuestionDelete = (question) => {
    axios
      .delete(`http://localhost:8081/questions/delete/${question.q_id}`)
      .then(() => {
        navigate("/Admin/QuestionAdmin");
      })
      .catch((error) => {
        if (error.response) {
          console.error("Server error:", error.response.status, error.response.data);
        } else if (error.request) {
          console.error("No response received. Check your network connection.");
        } else {
          console.error("Error:", error.message);
        }
      });
  };
  
  useEffect(() => {
    getQuestion(q_id);
  }, [q_id]);

  if(!token){
    return <Navigate to = "/AdminLogin"/>
  }
  return (
    <>
      <div className="container-md">
        <div className="container-md mt-3 px-5 text-center">
          <div className="container shadow border pb-3 bg-body-tertiary">
            <p className="fw-semibold mt-3 h2 text-secondary-emphasis text-center">
              Question
            </p>
            <hr />
            <div className="row mb-3">
              <div className="col">
                <p className="fw-semibold   text-end">q_id : </p>
              </div>
              <div className="col">
                <p className="fw-semibold   text-start">{questions.q_id} </p>
              </div>
            </div>
            <div className="row mb-3">
              <div className="col">
                <p className="fw-semibold   text-end">Question : </p>
              </div>
              <div className="col">
                <p className="fw-semibold   text-start">{questions.actual_qns} </p>
              </div>
            </div>
            <div className="row mb-3">
              <div className="col">
                <p className="fw-semibold   text-end">option1 : </p>
              </div>
              <div className="col">
                <p className="fw-semibold   text-start">{questions.option1} </p>
              </div>
            </div>
            <div className="row mb-3">
              <div className="col">
                <p className="fw-semibold   text-end">option2 : </p>
              </div>
              <div className="col">
                <p className="fw-semibold   text-start">{questions.option2} </p>
              </div>
            </div>
            <div className="row mb-3">
              <div className="col">
                <p className="fw-semibold   text-end">option3 : </p>
              </div>
              <div className="col">
                <p className="fw-semibold   text-start">{questions.option3} </p>
              </div>
            </div>
            <div className="row mb-3">
              <div className="col">
                <p className="fw-semibold   text-end">option4 : </p>
              </div>
              <div className="col">
                <p className="fw-semibold   text-start">{questions.option4} </p>
              </div>
            </div>
            <div className="row mb-3">
              <div className="col">
                <p className="fw-semibold text-end">level : </p>
              </div>
              <div className="col">
                <p className="fw-semibold text-start">
                  {questions.level}{" "}
                </p>
              </div>
            </div>
            <div className="row mb-3">
              <div className="col">
                <p className="fw-semibold text-end">Subject : </p>
              </div>
              <div className="col">
                <p className="fw-semibold text-start">
                  {questions.subject && questions.subject.subject_name}{" "}
                </p>
              </div>
            </div>
            <div className="row mb-3">
              <div className="col">
                <p className="fw-semibold text-end">correct_op : </p>
              </div>
              <div className="col">
                <p className="fw-semibold text-start">
                  {questions.correct_op}{" "}
                </p>
              </div>
            </div>
            <button
              className="btn btn-dark fw-semibold btn-lg btn-block text-light"
              type="button"
              onClick={() => {
                navigate("/Admin/UpdateQuestion", { state: { questions } });
              }}
            >
              Edit Question
            </button>
            <button
              type="button"
              onClick={() => handleQuestionDelete(questions)}
              class="btn ms-4 btn-dark fw-semibold btn-lg btn-block text-light"
            >
              Delete Question
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewOneQuestion;
