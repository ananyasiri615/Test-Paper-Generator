
import React, { useState, useEffect } from 'react';
import { Navigate, useNavigate } from "react-router-dom";
import './CandidateHistoryTable.css';
import { Bar } from 'react-chartjs-2';
import Chart from 'chart.js/auto';


function CandidateHistoryTable() {
  const [candidateHistories, setCandidateHistories] = useState([]);
  const token = localStorage.getItem("admin")
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:8081/candidatehistory/all')
      .then((response) => response.json())
      .then((data) => {
        setCandidateHistories(data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);

  const labels = candidateHistories.map((candidateHistory) => candidateHistory.username);
  const scores = candidateHistories.map((candidateHistory) => candidateHistory.totalscore);

  const data = {
    labels: labels,
    datasets: [
      {
        label: 'Total Scores',
        data: scores,
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 0.5,
      },
    ],
  };

  const options = {
    scales: {
      y: {
        type: 'linear',
        beginAtZero: true,
        title: {
          display: true,
          text: 'Total Scores',
        },
      },
      x: {
        type: 'category',
        title: { 
          display: true,
          text: 'Candidates',
        },
      },
    },
  };

  const sortedCandidates = candidateHistories.sort((a, b) => b.totalscore - a.totalscore);

  const top3Scorers = sortedCandidates.slice(0, 3);

  const top3Labels = top3Scorers.map((candidate) => candidate.username);
  const top3Scores = top3Scorers.map((candidate) => candidate.totalscore);

  const top3Data = {
    labels: top3Labels,
    datasets: [
      {
        label: 'Top 3 Scorers',
        data: top3Scores,
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
      },
    ],
  };

  const top3Options = {
    scales: {
      y: {
        type: 'linear',
        beginAtZero: true,
        title: {
          display: true,
          text: 'Total Scores',
        },
      },
      x: {
        type: 'category',
        title: {
          display: true,
          text: 'Candidates',
        },
      },
    },
  };
  if(!token){
    return <Navigate to = "/AdminLogin"/>
  }
  return (
    <div className="covr">
      <h3 style={{padding:"20px",marginLeft:"400px"}}>Candidates History</h3>
      <div className="table-container">
        <table className="candidate-table">
          <thead>
            <tr>
              {/* <th>ID</th> */}
              <th>Username</th>
              <th>Score</th>
              <th>Grade</th>
              <th>Start Time</th>
              <th>End Time</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {candidateHistories.map((candidateHistory) => (
              <tr key={candidateHistory.id}>
                {/* <td>{candidateHistory.id}</td> */}
                <td>{candidateHistory.username}</td>
                <td>{candidateHistory.totalscore}</td>
                <td>{candidateHistory.grade}</td>
                <td>{candidateHistory.startTime}</td>
                <td>{candidateHistory.endTime}</td>
                <td>{candidateHistory.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <br /><br />
      <div className="chart-container" style={{ width: '800px', height: '500px' }}>
        <Bar data={data} options={options} />
      </div>

      <div className="chart-container" style={{ width: '800px', height: '500px' }}>
        <h3>Top 3 Scorers</h3>
        <Bar data={top3Data} options={top3Options} />
      </div>
    </div>
  );
}

export default CandidateHistoryTable;

