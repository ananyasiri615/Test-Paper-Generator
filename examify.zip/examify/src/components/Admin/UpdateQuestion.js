import React, { useEffect, useState } from "react";
import axios from "axios";
import { useLocation, useNavigate, Navigate } from "react-router-dom";

const UpdateQuestion = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const questions = location.state.questions;

  const [actual_qns, setActualQns] = useState(questions ? questions.actual_qns : "");
  const [option1, setOption1] = useState(questions ? questions.option1 : "");
  const [option2, setOption2] = useState(questions ? questions.option2 : "");
  const [option3, setOption3] = useState(questions ? questions.option3 : "");
  const [option4, setOption4] = useState(questions ? questions.option4 : "");
  const [correct_op, setCorrectOp] = useState(questions ? questions.correct_op : "");
  const [level, setLevel] = useState(questions ? questions.level : "");
  const [subjectId, setSubjectId] = useState(questions ? questions.subject.subjectId : "");
  const token = localStorage.getItem("admin")

  useEffect(() => {
    setSubjectId(questions ? questions.subject.subjectId : "");
  }, [questions]);

  const handleSubmit = (event) => {
    event.preventDefault();

    const updatedQuestionsData = {
      q_id: questions.q_id,
      actual_qns,
      option1,
      option2,
      option3,
      option4,
      correct_op,
      level,
      subject: {
        subjectId: subjectId,
      },
    };

    axios
      .put(
        `http://localhost:8081/questions/update/${questions.q_id}`,
        updatedQuestionsData
      )
      .then((response) => {
        console.log("Success!! Data updated!", response.data);
        navigate("/Admin/QuestionAdmin");
      })
      .catch((error) => {
        if (error.response) {
          console.error("Server error:", error.response.status, error.response.data);
        } else if (error.request) {
          console.error("No response received. Check your network connection.");
        } else {
          console.error("Error:", error.message);
        }
      });
  };
  if(!token){
    return <Navigate to = "/AdminLogin"/>
  }
  return (
    <>
      <div className="container-md">
        <br />
        <p className="fw-semibold h2 text-secondary-emphasis text-center">
          Edit Question
        </p>
        <hr />
        <br />
        <div className="container-md px-5">
          <form onSubmit={handleSubmit}>
          <div className="row">
              <div className="col-md-6 mb-4">
                <label
                  className="form-label text-start fw-semibold text-info fs-5"
                  htmlFor="actualQnsInput"
                >
                  Actual Question
                </label>
                <input
                  type="text"
                  name="actual_qns"
                  id="actualQnsInput"
                  className="form-control"
                  value={actual_qns}
                  onChange={(e) => setActualQns(e.target.value)}
                />
              </div>

              <div className="col-md-6 mb-4">
                <label
                  className="form-label text-info fw-semibold fs-5"
                  htmlFor="levelInput"
                >
                  Level
                </label>
                <input
                  type="number"
                  name="level"
                  id="levelInput"
                  className="form-control"
                  value={level}
                  onChange={(e) => setLevel(e.target.value)}
                />
              </div>
            </div>

            <div className="row">
              <div className="col-md-6 mb-4">
                <label
                  className="form-label fw-semibold text-info fs-5"
                  htmlFor="option1Input"
                >
                  Option 1
                </label>
                <input
                  type="text"
                  name="option1"
                  id="option1Input"
                  className="form-control"
                  value={option1}
                  onChange={(e) => setOption1(e.target.value)}
                />
              </div>

              <div className="col-md-6 mb-4">
                <label
                  className="form-label fw-semibold text-info fs-5"
                  htmlFor="option2Input"
                >
                  Option 2
                </label>
                <input
                  type="text"
                  name="option2"
                  id="option2Input"
                  className="form-control"
                  value={option2}
                  onChange={(e) => setOption2(e.target.value)}
                />
              </div>
            </div>

            <div className="row">
              <div className="col-md-6 mb-4">
                <label
                  className="form-label fw-semibold text-info fs-5"
                  htmlFor="option3Input"
                >
                  Option 3
                </label>
                <input
                  type="text"
                  name="option3"
                  id="option3Input"
                  className="form-control"
                  value={option3}
                  onChange={(e) => setOption3(e.target.value)}
                />
              </div>

              <div className="col-md-6 mb-4">
                <label
                  className="form-label fw-semibold text-info fs-5"
                  htmlFor="option4Input"
                >
                  Option 4
                </label>
                <input
                  type="text"
                  name="option4"
                  id="option4Input"
                  className="form-control"
                  value={option4}
                  onChange={(e) => setOption4(e.target.value)}
                />
              </div>
            </div>

            <div className="row">
              <div className="col-md-6 mb-4">
                <label
                  className="form-label fw-semibold text-info fs-5"
                  htmlFor="correctOpInput"
                >
                  Correct Option
                </label>
                <input
                  type="text"
                  name="correct_op"
                  id="correctOpInput"
                  className="form-control"
                  value={correct_op}
                  onChange={(e) => setCorrectOp(e.target.value)}
                />
              </div>

              <div className="col-md-6 mb-4">
                <label
                  className="form-label fw-semibold text-info fs-5"
                  htmlFor="subjectIdInput"
                >
                  Subject ID
                </label>
                <input
                  type="number"
                  name="subjectId"
                  id="subjectIdInput"
                  className="form-control"
                  value={subjectId}
                  onChange={(e) => setSubjectId(e.target.value)}
                />
              </div>
            </div>

            <br />

            <div className="pt-1 mb-4 text-center">
              <button
                className="btn btn-dark fw-semibold btn-lg btn-block text-light"
                type="submit"
              >
                Edit Question
              </button>
            </div>          
            </form>
        </div>
      </div>
    </>
  );
};

export default UpdateQuestion;

