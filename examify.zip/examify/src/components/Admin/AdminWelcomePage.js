// import React, { useEffect, useState } from "react";
// import { Navigate, useNavigate } from "react-router-dom";
// import workingGirl from "./images/working-girl.png";
// import "./AdminWelcomePage.css"; 

// const AdminWelcomePage = () => {
//   const [admin, SetAdmin] = useState("");
//   const token = localStorage.getItem("admin")
//   const navigate = useNavigate();

//   useEffect(() => {
//     const storedUsername = localStorage.getItem("admin");
//     SetAdmin(storedUsername);
//   }, []);

//   if(!token){
//     return <Navigate to = "/AdminLogin"/>
//   }
//   return (
//     <div className="container1">
//       <div
//         className="hero-container1 container1"
//         style={{ background: "transparent", boxShadow: "none" , paddingRight:"100px"}}
//       >
//         <div className="hero_detail-box">
//           <h3>Hello {admin}!! <br />Are You Ready??</h3>
//           <div className="hero_btn-container1" >
//             <a
//               href="/Admin/QuestionAdmin"
//               className="call_to-btn btn_white-border"
//             >
//               Get Started
//             </a>
//           </div>
//         </div>
//         <div className="hero_img-container1" style={{marginLeft:"400px"}}>
//           <div>
//             <img src={workingGirl} alt="" className="img-fluid" />
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };
// export default AdminWelcomePage;
import React, { useEffect, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import workingGirl from "./images/working-girl.png";
import "./AdminWelcomePage.css"; 

const AdminWelcomePage = () => {
  const [admin, SetAdmin] = useState("");
  const token = localStorage.getItem("admin")
  const navigate = useNavigate();

  useEffect(() => {
    const storedUsername = localStorage.getItem("admin");
    SetAdmin(storedUsername);
  }, []);

  if(!token){
    return <Navigate to = "/AdminLogin"/>
  }
  return (
    <div className="container1">
      <div
        className="hero-container1 container1"
        style={{ background: "transparent", boxShadow: "none" }}
      >
        <div className="hero_detail-box">
          <h1>Hello {admin}!! <br />Are You Ready??</h1>
          <div className="hero_btn-container1" >
            <a
              href="/Admin/QuestionAdmin"
              className="call_to-btn btn_white-border"
            >
              Get Started
            </a>
          </div>
        </div>
        <div className="hero_img-container1" style={{marginLeft:"400px"}}>
          <div>
            <img src={workingGirl} alt="" className="img-fluid" />
          </div>
        </div>
      </div>
    </div>
  );
};
export default AdminWelcomePage;
