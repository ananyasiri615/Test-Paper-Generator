import React, { useState, useEffect } from "react";
import axios from "axios";
import { Navigate, useNavigate } from "react-router-dom";
import "./CandidateAdmin.css";

function CandidateAdmin() {
  const [candidates, setCandidates] = useState([]);
  const [newCandidate, setNewCandidate] = useState({
    name: "",
    email: "",
    phoneNo: "",
    username: "",
    password: "",
  });
  const [selectedCandidateId, setSelectedCandidateId] = useState(null);
  const [candidateDetails, setCandidateDetails] = useState(null);
  const token = localStorage.getItem("admin");
  const [errorMessage, setErrorMessage] = useState("");
  const [emailError, setEmailError] = useState("");
  const [phoneNoError, setPhoneNoError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:8081/candidates/all")
      .then((response) => {
        setCandidates(response.data);
      })
      .catch((error) => {
        if (error.response) {
          console.error(
            `Request failed with status code: ${error.response.status}`
          );
          console.error(error.response.data);
        } else if (error.request) {
          console.error("No response received. Check your network connection.");
        } else {
          console.error(`Error: ${error.message}`);
        }
      });
  }, []);

  const handleAddCandidate = () => {
    const isFormValid = validateForm();

    if (!isFormValid) {
      return;
    }

    axios
      .post("http://localhost:8081/candidates/create", newCandidate)
      .then((response) => {
        setCandidates([...candidates, response.data]);
        setNewCandidate({
          name: "",
          email: "",
          phoneNo: "",
          username: "",
          password: "",
        });
      })
      .catch((error) => {
        if (error.response && error.response.status === 500) {
          setErrorMessage(
            "Error: Same email, phone number, or username exists."
          );
        } else {
          console.error(error);
        }
      });
  };
  const isEmailValid = (email) => {
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    return emailRegex.test(email);
  };

  const isPasswordValid = (password) => {
    const passwordRegex =
      /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&!_+=-]).{8,}$/;
    return passwordRegex.test(password);
  };

  const isPhoneNoValid = (phoneNo) => {
    const phoneNoRegex = /^\d{10}$/;
    return phoneNoRegex.test(phoneNo);
  };
  const validateForm = () => {
    let valid = true;
    if (!isEmailValid(newCandidate.email)) {
      setEmailError("Invalid email");
      valid = false;
    } else {
      setEmailError("");
    }

    if (!isPasswordValid(newCandidate.password)) {
      setPasswordError("Invalid password");
      valid = false;
    } else {
      setPasswordError("");
    }

    if (!isPhoneNoValid(newCandidate.phoneNo)) {
      setPhoneNoError("Invalid phone number");
      valid = false;
    } else {
      setPhoneNoError("");
    }
    return valid; // Return the valid status
  };
  const handleGetCandidateDetails = (candidateId) => {
    axios
      .get(`http://localhost:8081/candidates/${candidateId}`)
      .then((response) => {
        setCandidateDetails(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handleUpdateCandidate = (candidateId) => {
    axios
      .put(`http://localhost:8081/candidates/${candidateId}`, newCandidate)
      .then((response) => {
        const updatedCandidates = candidates.map((candidate) =>
          candidate.candidateId === candidateId ? response.data : candidate
        );
        setCandidates(updatedCandidates);
        setNewCandidate({
          name: "",
          email: "",
          phoneNo: "",
          username: "",
          password: "",
        });
        window.location.reload();
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handleDeleteCandidate = (candidateId) => {
    axios
      .delete(`http://localhost:8081/candidates/${candidateId}`)
      .then(() => {
        const updatedCandidates = candidates.filter(
          (candidate) => candidate.candidateId !== candidateId
        );
        setCandidates(updatedCandidates);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handleSelectCandidate = (candidate) => {
    setSelectedCandidateId(candidate.candidateId);
    setNewCandidate({
      name: candidate.name,
      email: candidate.email,

      phoneNo: candidate.phoneNo,
      username: candidate.username,
      password: candidate.password,
    });
  };
  if (!token) {
    return <Navigate to="/AdminLogin" />;
  }

  return (
    <div className="wrapper1">
      <div className="container" style={{ backgroundColor: "#f0f0f0" }}>
        <h3 className="mt-4" style={{ marginLeft: "400px" }}>
          Add/update candidate
        </h3>
        {errorMessage && (
          <div className="alert alert-danger" role="alert">
            {errorMessage}
          </div>
        )}
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            placeholder="Name"
            value={newCandidate.name}
            onChange={(e) =>
              setNewCandidate({ ...newCandidate, name: e.target.value })
            }
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            placeholder="Email"
            value={newCandidate.email}
            onChange={(e) =>
              setNewCandidate({ ...newCandidate, email: e.target.value })
            }
          />
        </div>
        <div className="form-group">
          <input
            type="number"
            className="form-control"
            placeholder="Phone Number"
            value={newCandidate.phoneNo}
            onChange={(e) =>
              setNewCandidate({ ...newCandidate, phoneNo: e.target.value })
            }
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            placeholder="Username"
            value={newCandidate.username}
            onChange={(e) =>
              setNewCandidate({ ...newCandidate, username: e.target.value })
            }
          />
        </div>
        <div className="form-group">
          <input
            type="password"
            className="form-control"
            placeholder="Password"
            value={newCandidate.password}
            onChange={(e) =>
              setNewCandidate({ ...newCandidate, password: e.target.value })
            }
          />
        </div>
        <button
          className="btn btn-primary"
          onClick={
            selectedCandidateId ? handleUpdateCandidate : handleAddCandidate
          }
        >
          {selectedCandidateId ? "Update" : "Add"}
        </button>
        {phoneNoError && (
          <div className="alert alert-danger" role="alert">
            {phoneNoError}
          </div>
        )}
        {emailError && (
          <div className="alert alert-danger" role="alert">
            {emailError}
          </div>
        )}
        {passwordError && (
          <div className="alert alert-danger" role="alert">
            {passwordError}
          </div>
        )}
        <h3 className="mt-4" style={{ marginLeft: "420px" }}>
          List of candidates
        </h3>
        <ul className="list-group">
          {candidates.map((candidate) => (
            <li key={candidate.candidateId} className="list-group-item">
              {selectedCandidateId === candidate.candidateId ? (
                <div>
                  <button
                    className="btn btn-success"
                    onClick={() => handleUpdateCandidate(candidate.candidateId)}
                  >
                    Save
                  </button>
                  
                </div>
              ) : (
                <div>
                  <p>
                    <strong>Name:</strong> {candidate.name}
                  </p>
                  <p>
                    <strong>Email:</strong> {candidate.email}
                  </p>
                  <p>
                    <strong>Phone Number:</strong> {candidate.phoneNo}
                  </p>
                  <button
                    className="btn btn-info"
                    onClick={() => handleSelectCandidate(candidate)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={() => handleDeleteCandidate(candidate.candidateId)}
                  >
                    Delete
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>
        
        {/* Candidate details section */}
        <div className="mt-4">
          <h3 style={{ marginLeft: "400px" }}>
            Get candidate details by candidate ID
          </h3>
          <div className="form-group">
            <input
              type="number"
              className="form-control"
              placeholder="Enter Candidate ID"
              value={selectedCandidateId}
              onChange={(e) => setSelectedCandidateId(e.target.value)}
            />
          </div>
          <button
            className="btn btn-primary"
            onClick={() => handleGetCandidateDetails(selectedCandidateId)}
          >
            Get Details
          </button>
        </div>

        {candidateDetails && (
          <div className="mt-4">
            <h3>Candidate Details</h3>
            <p>
              <strong>Name:</strong> {candidateDetails.name}
            </p>
            <p>
              <strong>Email:</strong> {candidateDetails.email}
            </p>
            <p>
              <strong>Phone Number:</strong> {candidateDetails.phoneNo}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default CandidateAdmin;
