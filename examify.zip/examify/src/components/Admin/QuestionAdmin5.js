import React, { useState, useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import * as xlsx from "xlsx"; 
import axios from "axios";
import "./QuestionAdmin.css";

function QuestionAdmin() {
  const [questions, setQuestions] = useState([]);
  const [actual_qns, setActual_qns] = useState("");
  const [option1, setOption1] = useState(""); 
  const [option2, setOption2] = useState("");
  const [option3, setOption3] = useState(""); 
  const [option4, setOption4] = useState("");
  const [correct_op, setCorrect_op] = useState("");
  const [level, setLevel] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const token = localStorage.getItem("admin");
  const navigate = useNavigate();

  const handleViewQuestion = (q_id) => {
    navigate("/Admin/ViewOneQuestion", { state: { q_id } });
  };
  const handleExcelFileUpload = async (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();

      reader.onload = async (e) => {
        const data = new Uint8Array(e.target.result);
        const workbook = xlsx.read(data, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = xlsx.utils.sheet_to_json(sheet, { defval: null });

        const mappedData = jsonData.map((item) => ({
          actual_qns: item.actual_qns,
          option1: item.option1,
          option2: item.option2,
          option3: item.option3,
          option4: item.option4,
          correct_op: item.correct_op,
          level: item.level,
          subject: { subjectId: item["subject.subjectId"] }, // Access subjectId from the nested structure
        }));

        try {
          const response = await axios.post(
            "http://localhost:8081/questions/createMultiple",
            mappedData
          );
          console.log("Successfully uploaded questions:", response.data);
        } catch (error) {
          console.error("Error uploading questions:", error);
        }
      };

      reader.readAsArrayBuffer(file);
    }
  };

  const handleAddQuestion = (e) => {
    e.preventDefault();
    const Questions = {
      actual_qns,
      option1,
      option2,
      option3,
      option4,
      correct_op,
      level,
      subjectId: ["subject.subjectId"],
    };

    axios
      .post("http://localhost:8081/questions/create", Questions)
      .then((response) => {
        if (response.data.error) {
          setErrorMessage("Error: " + response.data.error);
        } else {
          setQuestions([...questions, response.data]);
          setActual_qns("");
          setOption1("");
          setOption2("");
          setOption3("");
          setOption4("");
          setCorrect_op("");
          setLevel("");
          setSubjectId("");
          setErrorMessage("");
        }
      })
      .catch((error) => {
        if (error.response && error.response.status === 500) {
          setErrorMessage(
            "Error: A question with the same content already exists."
          );
        } else {
          console.error(error);
        }
      });
  };

  useEffect(() => {
    axios
      .get("http://localhost:8081/questions/all")
      .then((response) => {
        console.log(response.data);
        setQuestions(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);
  if (!token) {
    return <Navigate to="/AdminLogin" />;
  }
  return (
    <div className="wrapper" >
      <div className="container question-admin-container1" style={{backgroundColor:"#f0f0f0"}}>
        <div className="row">
          <div className="col-md-10 mx-auto">
            <h3 style={{marginLeft: "350px", marginTop:"20px"}}>Add Question</h3>
            {errorMessage && (
              <div className="alert alert-danger" role="alert">
                {errorMessage}
              </div>
            )}
            <form>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter a new question"
                  value={actual_qns}
                  onChange={(e) => setActual_qns(e.target.value)}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Option 1"
                  value={option1}
                  onChange={(e) => setOption1(e.target.value)}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Option 2"
                  value={option2}
                  onChange={(e) => setOption2(e.target.value)}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Option 3"
                  value={option3}
                  onChange={(e) => setOption3(e.target.value)}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Option 4"
                  value={option4}
                  onChange={(e) => setOption4(e.target.value)}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Correct Option"
                  value={correct_op}
                  onChange={(e) => setCorrect_op(e.target.value)}
                />
              </div>
              <div className="form-group">
                <input
                  type="number"
                  className="form-control"
                  placeholder="Level"
                  value={level}
                  onChange={(e) => setLevel(e.target.value)}
                />
              </div>
              <div className="form-group">
                <input
                  type="number"
                  className="form-control"
                  placeholder="Subject ID"
                  value={subjectId}
                  onChange={(e) => setSubjectId(e.target.value)}
                />
              </div>
              <button className="btn btn-primary" onClick={handleAddQuestion}>
                Add
              </button>
            </form>
          </div>
        </div>
        <br /><br />
        <div className="row">
          <div className="col-md-10 mx-auto">
            <h3>Upload Questions from Excel</h3>
            <div className="form-group">
              <input
                type="file"
                accept=".xlsx, .xls"
                onChange={handleExcelFileUpload}
              />
            </div>
          </div>
        </div>
        <br /><br />
        <div className="row">
          <div className="col-md-10 mx-auto">
            <h3 style={{marginLeft:"350px"}}>List of Questions</h3> <br />
            <div className="table-responsive">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Question</th>
                    <th>Options</th>
                    <th>Correct Option</th>
                    <th>Level</th>
                    <th>Subject</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {questions.map((question) => (
                    <tr key={question.q_id}>
                      <th scope="row">{question.q_id}</th>
                      <td>{question.actual_qns}</td>
                      <td>
                        <ul>
                          <li>{question.option1}</li>
                          <li>{question.option2}</li>
                          <li>{question.option3}</li>
                          <li>{question.option4}</li>
                        </ul>
                      </td>
                      <td>{question.correct_op}</td>
                      <td>{question.level}</td>
                      <td>{question.subject?.subject_name || "N/A"}</td>
                      <th scope="col">
                        <button
                          type="button"
                          onClick={() => handleViewQuestion(question.q_id)}
                          className="btn btn-outline-success"
                        >
                          View
                        </button>
                      </th>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default QuestionAdmin;
