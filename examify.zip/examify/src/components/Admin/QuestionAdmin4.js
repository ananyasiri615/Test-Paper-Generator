import React, { useState, useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import axios from "axios";
import "./QuestionAdmin.css";

function QuestionAdmin() {
  const [questions, setQuestions] = useState([]);
  const [tableItems, setTableItems] = useState([]);
  const navigate = useNavigate();
  const [newQuestionData, setNewQuestionData] = useState({
    actual_qns: "",
    option1: "",
    option2: "",
    option3: "",
    option4: "",
    correct_op: "",
    level: 1,
    subjectId: 1, // Change to subjectId
  });

  useEffect(() => {
    axios
      .get("http://localhost:8081/questions/all")
      .then((response) => {
        console.log(response.data);
        setTableItems(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const handleAddQuestion = () => {
    axios
      .post("http://localhost:8081/questions/create", newQuestionData)
      .then((response) => {
        setQuestions([...questions, response.data]);

        setNewQuestionData({
          actual_qns: "",
          option1: "",
          option2: "",
          option3: "",
          option4: "",
          correct_op: "",
          level: 1,
          subjectId: 1,
        });
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handleViewQuestion = (q_id) => {
    // Navigate to the ViewOneQuestion component and pass the q_id as state
    navigate("/Admin/ViewOneQuestion", { state: { q_id } });
  };

  return (
    <div className="wrapper">
      <div className="container question-admin-container">
        <div className="row">
          <div className="col-md-10 mx-auto">
            <h2>Add Question</h2>
            <form>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Enter a new question"
                    value={newQuestionData.actual_qns}
                    onChange={(e) =>
                      setNewQuestionData({
                        ...newQuestionData,
                        actual_qns: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Option 1"
                    value={newQuestionData.option1}
                    onChange={(e) =>
                      setNewQuestionData({
                        ...newQuestionData,
                        option1: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Option 2"
                    value={newQuestionData.option2}
                    onChange={(e) =>
                      setNewQuestionData({
                        ...newQuestionData,
                        option2: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Option 3"
                    value={newQuestionData.option3}
                    onChange={(e) =>
                      setNewQuestionData({
                        ...newQuestionData,
                        option3: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Option 4"
                    value={newQuestionData.option4}
                    onChange={(e) =>
                      setNewQuestionData({
                        ...newQuestionData,
                        option4: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Correct Option"
                    value={newQuestionData.correct_op}
                    onChange={(e) =>
                      setNewQuestionData({
                        ...newQuestionData,
                        correct_op: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="form-group">
                  <input
                    type="number"
                    className="form-control"
                    placeholder="level"
                    value={newQuestionData.level}
                    onChange={(e) =>
                      setNewQuestionData({
                        ...newQuestionData,
                        level: parseInt(e.target.value),
                      })
                    }
                  />
                </div>
                <div className="form-group">
                  <input
                    type="number"
                    className="form-control"
                    placeholder="Subject ID"
                    value={newQuestionData.subjectId}
                    onChange={(e) =>
                      setNewQuestionData({
                        ...newQuestionData,
                        subjectId: parseInt(e.target.value),
                      })
                    }
                  />
                </div>
                <button className="btn btn-primary" onClick={handleAddQuestion}>
                  Add
                </button>
              </form>
          </div>
        </div>
        <div className="row">
          <div className="col-md-10 mx-auto">
            <h2>List Questions</h2>
            <div className="table-responsive">
            <table className="table table-striped ">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Question</th>
                  <th>Options</th>
                  <th>Correct Option</th>
                  <th>Level</th>
                  <th>Subject</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {tableItems.map((questions) => (
                  <tr key={questions.q_id}>
                  <th scope="row">{questions.q_id}</th>
                  <td>{questions.actual_qns}</td>
                  <td>
                    <ul>
                      <li>{questions.option1}</li>
                      <li>{questions.option2}</li>
                      <li>{questions.option3}</li>
                      <li>{questions.option4}</li>
                    </ul>
                  </td>
                  <td>{questions.correct_op}</td>
                  <td>{questions.level}</td>
                  <td>{questions.subject?.subject_name || "N/A"}</td>
                  {/* Use optional chaining and provide a default value */}
                  <th scope="col">
                    <button
                      type="button"
                      onClick={() => handleViewQuestion(questions.q_id)}
                      className="btn btn-outline-success"
                    >
                      View
                    </button>
                  </th>
                </tr>
                ))}
              </tbody>
            </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default QuestionAdmin;
