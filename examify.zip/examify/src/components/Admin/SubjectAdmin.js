import React, { useState, useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import axios from "axios";
import "./SubjectAdmin.css";

function SubjectAdmin() {
  const [subjects, setSubjects] = useState([]);
  const [errorMessage, setErrorMessage] = useState("");
  const [newSubjectData, setNewSubjectData] = useState({
    subject_name: "",
  });
  const [updatingSubject, setUpdatingSubject] = useState(null);
  const token = localStorage.getItem("admin")
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:8081/subjects/all")
      .then((response) => {
        setSubjects(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const handleUpdateSubject = (subjectId) => {
    const subjectToUpdate = subjects.find(
      (subject) => subject.subjectId === subjectId
    );

    if (subjectToUpdate) {
      setUpdatingSubject(subjectToUpdate);
      setNewSubjectData({ subject_name: subjectToUpdate.subject_name });
    } else {
      console.error("Subject not found for update.");
    }
  };

  const handleAddSubject = () => {
    axios
      .post("http://localhost:8081/subjects/create", newSubjectData)
      .then((response) => {
        setSubjects([...subjects, response.data]);
        setNewSubjectData({ subject_name: "" });
      })
      .catch((error) => {
        if (error.response && error.response.status === 400) {
          
          setErrorMessage("Subject already exists.");
        }else{
        console.error(error);
        }
      });
  };

  const handleSaveSubject = (subjectId) => {
    const updatedSubjectData = { ...newSubjectData };

    axios
      .put(
        `http://localhost:8081/subjects/update/${subjectId}`,
        updatedSubjectData
      )
      .then((response) => {
        const updatedSubjects = subjects.map((subject) =>
          subject.subjectId === subjectId
            ? { ...subject, ...updatedSubjectData }
            : subject
        );
        setSubjects(updatedSubjects);
        setUpdatingSubject(null);
        setNewSubjectData({ subject_name: "" });
      })
      .catch((error) => {
        console.error(error);
      });
  };
  if(!token){
    return <Navigate to = "/AdminLogin"/>
  }
  
  return (
    <div className="wrapper1">
      <div className="container subject-admin-container" style={{backgroundColor:"#f0f0f0"}}>
        <div className="row">
          <div className="col-md-8" mx-auto>
          <h3 style={{marginLeft:"450px",padding:"10px"}}>Add/update subject</h3>
            {errorMessage && (
              <div className="alert alert-danger" role="alert">
                {errorMessage}
              </div>
            )}
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                placeholder="Subject Name"
                value={newSubjectData.subject_name}
                onChange={(e) =>
                  setNewSubjectData({ subject_name: e.target.value })
                }
              />
            </div>
            <button
              className="btn btn-primary"
              onClick={
                updatingSubject
                  ? () => handleSaveSubject(updatingSubject.subjectId)
                  : handleAddSubject
              }
            >
              {updatingSubject ? "Update" : "Add"}
            </button>
          </div>
        </div>
        <div className="row">
          <div className="col-md-8 mx-auto">
          <h3 style={{marginLeft:"310px",padding:"10px"}}>List of subjects</h3>
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Subject ID</th>
                  <th>Subject Name</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {subjects.map((subject) => (
                  <tr key={subject.subjectId}>
                    <td>{subject.subjectId}</td>
                    <td>
                      {updatingSubject === subject ? (
                        <input
                          type="text"
                          className="form-control"
                          value={newSubjectData.subject_name}
                          onChange={(e) =>
                            setNewSubjectData({ subject_name: e.target.value })
                          }
                        />
                      ) : (
                        subject.subject_name
                      )}
                    </td>
                    <td>
                      {updatingSubject === subject ? (
                        <button
                          className="btn btn-success"
                          onClick={() => handleSaveSubject(subject.subjectId)}
                        >
                          Save
                        </button>
                      ) : (
                        <div>
                          <button
                            className="btn btn-info"
                            onClick={() =>
                              handleUpdateSubject(subject.subjectId)
                            }
                          >
                            Edit
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SubjectAdmin;
