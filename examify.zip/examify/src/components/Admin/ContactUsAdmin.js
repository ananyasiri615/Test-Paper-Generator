import React, { useState, useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import axios from "axios";
import "./QuestionAdmin.css";

function ContactUsAdmin() {
  const [inquiries, setInquiries] = useState([]);
  const token = localStorage.getItem("admin");
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:8081/contact/all")
      .then((response) => {
        console.log(response.data);
        setInquiries(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  if (!token) {
    // Redirect to login if the admin is not authenticated
    return <Navigate to="/AdminLogin" />;
  }

  return (
    <div className="wrapper">
      <div className="container contact-us-admin-container" style={{ backgroundColor: "#f0f0f0" }}>
        <div className="row">
          <div className="col-md-10 mx-auto">
            <h3 style={{ marginLeft: "400px", marginTop: "20px" }}>Contact Enquiries</h3>
            <br /><br />
            <div className="table-responsive">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>phone number</th>
                    <th>Message</th>
                  </tr>
                </thead>
                <tbody>
                  {inquiries.map((inquiry) => (
                    <tr key={inquiry.contactId}>
                      <th scope="row">{inquiry.contactId}</th>
                      <td>{inquiry.name}</td>
                      <td>{inquiry.email}</td>
                      <td>{inquiry.phone}</td>
                      <td>{inquiry.message}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ContactUsAdmin;
