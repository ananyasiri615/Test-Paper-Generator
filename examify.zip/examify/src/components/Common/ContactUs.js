import React, { useState } from "react";
import axios from "axios";
import "./ContactUs.css";
import students from "./images/students.jpg";

const ContactUs = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [errorMessage, setErrorMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Check if any field is empty
    if (!formData.name || !formData.email || !formData.phone || !formData.message) {
      setErrorMessage("Please enter all fields.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:8081/contact/submit", formData);

      if (response.status === 200) {
        console.log("Message sent successfully");
      } else {
        console.error("Error sending message");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div>
      <section className="contact_section">
        <div className="container" style={{ background: "transparent", border: "none", boxShadow: "none" }}>
          <div className="row">
            <div className="col-md-6">
              <div className="d-flex justify-content-center d-md-block">
                <h2>Contact Us</h2>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="contact_form-container">
                  {errorMessage && <div style={{ color: "red" }}>{errorMessage}</div>}
                  <div>
                    <input type="text" placeholder="Name" name="name" value={formData.name} onChange={handleChange} />
                  </div>
                  <div>
                    <input type="email" placeholder="Email" name="email" value={formData.email} onChange={handleChange} />
                  </div>
                  <div>
                    <input type="number" placeholder="Phone Number" name="phone" value={formData.phone} onChange={handleChange} />
                  </div>
                  <div>
                    <input type="text" placeholder="Message" name="message" value={formData.message} onChange={handleChange} />
                  </div>
                  <div className="mt-5">
                    <button type="submit">Send</button>
                  </div>
                </div>
              </form>
            </div>
            <div className="col-md-6">
              <div className="contact_img-box">
                <img src={students} alt="" className="small-image" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactUs;
