import React, { useRef, useEffect } from "react";
import "./WelcomePage.css";
import c from "./images/cimg.png";
import java from "./images/java.jpg";
import react from "./images/react.png";
import python from "./images/pt.png";
import sql from "./images/sql.png";
import cplus from "./images/c++.jpg";
import aboutImg from "../../images/about-img.jpg";
import sliderImage from "../../images/slider-img.png";
import experienceImage from "../../images/experience-img.jpg";
import Navbar from "./Navbar";
import { Link } from "react-router-dom";

function CommonWelcomePage() {
  const aboutus = useRef(null);
  const category = useRef(null);

  const scrollToSection = (elementRef) => {
    window.scrollTo({
      top: elementRef.current.offsetTop,
      behavior: "smooth",
    });
  };
  useEffect(() => {
    console.log(aboutus.current);
    console.log(category.current);
  }, []);

  return (
    <div>
      <Navbar
        scrollToAboutus={() => scrollToSection(aboutus)}
        scrollToCategory={() => scrollToSection(category)}
      />
      <div className="hero_area">
        <section className="slider_section">
          <div
            id="carouselExampleIndicators"
            className="carousel slide"
            data-ride="carousel"
          >
            <div className="carousel-inner">
              <div className="carousel-item active">
                <div
                  className="container-fluid"
                  style={{ background: "transparent", border: "none" }}
                >
                  <div className="row">
                    <div className="col-md-5 offset-md-1">
                      <div className="detail-box">
                        <h1>
                          You Can <br />
                          Take Tests <br />
                          Here <br />
                          And Check Your Performance
                        </h1>
                        <div className="btn-box">
                          <a
                            href="/AdminLogin"
                            className="btn-1"
                            style={{ textDecoration: "none" }}
                          >
                            Admin Login
                          </a>
                          <a
                            href="/Login"
                            className="btn-2"
                            style={{ textDecoration: "none" }}
                          >
                            Candidate Login
                          </a>
                        </div>
                      </div>
                    </div>
                    <div
                      className="offset-md-1 col-md-4 img-container"
                      style={{ background: "transparent", border: "none" }}
                    >
                      <div className="img-box">
                        <img src={sliderImage} alt="" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      <section ref={aboutus} className="about_section layout_padding">
        <div
          className="container"
          style={{
            background: "transparent",
            border: "none",
            boxShadow: "none",
          }}
        >
          <div className="row">
            <div className="col-md-5">
              <div className="img-box">
                <img src={aboutImg} alt="" />
              </div>
            </div>
            <div className="col-md-7">
              <div className="detail-box">
                <h2>About Examify</h2>
                <br />
                <p style={{ textAlign: "justify",color:"black" }}>
                  Welcome to Examify, where innovation meets education. Our Demo
                  Project Test Paper Generator is designed to revolutionize the
                  way you create and manage test papers. At Examify, we are
                  passionate about providing user-friendly, efficient, and
                  customizable tools for educators and institutions. Our team of
                  dedicated professionals has crafted Examify with a focus on
                  simplicity and effectiveness. We understand the importance of
                  seamless test paper creation, and our platform aims to
                  streamline this process for educators, saving time and
                  enhancing productivity.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section ref={category} className="category_section layout_padding">
        <div
          className="container"
          style={{
            background: "transparent",
            border: "none",
            boxShadow: "none",
            boxShadow: "none",
          }}
        >
          <div
            className="heading_container"
            style={{
              background: "transparent",
              border: "none",
              boxShadow: "none",
            }}
          >
            <h2>Subjects</h2>
          </div>
          <div
            className="category_container"
            style={{ background: "transparent", border: "none" }}
          >
            <div
              className="box"
              style={{ background: "transparent", border: "none" }}
            >
              <div className="img-box">
                <img src={java} alt="" />
              </div>
              <div className="detail-box">
                <h5>Java</h5>
              </div>
            </div>
            <div
              className="box"
              style={{ background: "transparent", border: "none" }}
            >
              <div className="img-box">
                <img src={react} alt="" />
              </div>
              <div className="detail-box">
                <h5>React</h5>
              </div>
            </div>
            <div
              className="box"
              style={{ background: "transparent", border: "none" }}
            >
              <div className="img-box">
                <img src={sql} alt="" />
              </div>
              <div className="detail-box">
                <h5>SQL</h5>
              </div>
            </div>
            <div
              className="box"
              style={{ background: "transparent", border: "none" }}
            >
              <div className="img-box" style={{ backgroundColor: "white" }}>
                <img src={python} alt="" />
              </div>
              <div className="detail-box">
                <h5>Python</h5>
              </div>
            </div>
            <div
              className="box"
              style={{ background: "transparent", border: "none" }}
            >
              <div className="img-box">
                <img src={cplus} alt="" />
              </div>
              <div className="detail-box">
                <h5>C++</h5>
              </div>
            </div>
            <div
              className="box"
              style={{ background: "transparent", border: "none" }}
            >
              <div className="img-box">
                <img src={c} alt="" />
              </div>
              <div className="detail-box">
                <h5>C</h5>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="experience_section layout_padding">
        <div
          className="container"
          style={{
            background: "transparent",
            border: "none",
            boxShadow: "none",
            boxShadow: "none",
          }}
        >
          <div className="row">
            <div className="col-md-5">
              <div className="img-box">
                <img src={experienceImage} alt="" />
              </div>
            </div>
            <div className="col-md-7">
              <div className="detail-box">
                <div
                  className="heading_container"
                  style={{
                    background: "transparent",
                    border: "none",
                    boxShadow: "none",
                  }}
                >
                  <h2>Experience Excellence with Examify</h2>
                </div>
                <p style={{ textAlign: "justify",color:"black" }}>
                  Embark on a seamless journey of expertise and proficiency with
                  Examify, your go-to platform for the best-experienced
                  freelancers. At Examify, we take pride in connecting you with
                  a network of highly skilled professionals who bring a wealth
                  of experience to the table.
                  <br />
                  <br />
                  <h4 style={{ color: "black" }}>Why Examify?</h4>
                  <ol>
                    <li style={{color:"black"}}>
                      <span
                        style={{ fontWeight: "bold", textAlign: "justify" }}
                      >
                        Talent:
                      </span>{" "}
                      Our stringent selection process ensures that you gain
                      access to the best and most experienced freelancers in
                      their respective fields.
                    </li>{" "}
                    <li style={{color:"black"}}>
                      <span
                        style={{ fontWeight: "bold", textAlign: "justify" }}
                      >
                        Proven Track Record:
                      </span>{" "}
                      Experience the reliability and excellence that our
                      freelancers have demonstrated through successful projects
                      and satisfied clients.
                    </li>
                    <li style={{color:"black"}}>
                      <span
                        style={{ fontWeight: "bold", textAlign: "justify" }}
                      >
                        Diverse Skill Sets:
                      </span>{" "}
                      From seasoned graphic designers to seasoned software
                      developers, Examify offers a diverse pool of experienced
                      freelancers ready to meet your project needs.
                    </li>
                  </ol>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="info_section">
        <div
          className="info_container"
          style={{ background: "transparent", border: "none" }}
        >
          <div
            className="container"
            style={{
              background: "transparent",
              border: "none",
              boxShadow: "none",
            }}
          >
            <div className="info_top">
              <div className="info_logo" >
                <img src="images/logo.png" alt="" />
                <span>Examify</span>
              </div>
            </div>
            <div className="info_main">
              <div className="row">
                <div className="col-md-2 col-lg-2" style={{marginLeft:"80px",marginTop:"-10px"}}>
                  <div className="info_link-box">
                    <h5>Useful Link</h5>
                    <ul>
                      <li className=" active">
                        <a className="" href="/">
                          Home <span className="sr-only">(current)</span>
                        </a>
                      </li>
                      <li className="">
                        <a className="" href="/">
                          About{" "}
                        </a>
                      </li>
                      <li className="">
                        <a className="" href="/ContactUs">
                          ContactUs{" "}
                        </a>
                      </li>
                      <li className="">
                        <a className="" href="/">
                          Subjects{" "}
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="col-md-2 col-lg-2 offset-lg-1" style={{marginLeft:"110px",marginTop:"-10px"}}>
                  <h5>Information</h5>
                  <p style={{color:"white"}}>
                  Examify, your go-to platform for the best-experienced
                  freelancers. At Examify, we take pride in connecting you with
                  a network of highly skilled professionals who bring a wealth
                  of experience to the table.
                  </p>
                </div>

                <div className="col-md-3  offset-lg-1">
                  <div className="info_form ">
                    <h5>Contact us</h5>
                    <form action="">
                      <input type="email" placeholder="Email" />
                      <button>Submit</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <footer className="container-fluid footer_section "style={{background:"none",border:"none"}}>
        <div className="container"style={{background:"none",border:"none",boxShadow:"none"}}>
          <p>
            &copy; <span id="displayDate"></span> All Rights Reserved By
            <Link to="/"> Examify</Link>
          </p>
        </div>
      </footer>
    </div>
  );
}
export default CommonWelcomePage;