import React, { useState, useEffect } from "react";
import { Link, Outlet, Navigate } from "react-router-dom";

const CandidateNavbar = () => {
  const [loginStatus, setLoginStatus] = useState(true);
  const [user, SetUser] = useState('');

  useEffect(() => {
    const storedUsername = localStorage.getItem('username');
    SetUser(storedUsername);
  }, []);

  const handleLogout = () => {
    localStorage.clear();
    setLoginStatus(false);
  };
  if (loginStatus === false) {
    return <Navigate to="/" />;
  }

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <a
          className="navbar-brand"
          href="/WelcomePage"
          style={{ marginLeft: "15px",marginTop:"-4px" }}
        >
          <b style={{fontSize:"20px"}}>Examify </b>
        </a>
        <div className="container-fluid">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
                <Link className="nav-link" to="/WelcomePage">
                  <b style={{color:"black",fontSize:"17px"}}>Home</b>
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/InstructionsAccess">
                  <b style={{color:"black",fontSize:"17px"}}>Take Test</b>
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/TestPaperHistory">
                  <b style={{color:"black",fontSize:"17px"}}>View History</b>
                </Link>
              </li>
              <li className="d-flex" style={{ marginLeft: "850px" }}>
                <button
                  type="button"
                  className="btn btn-light dropdown-item fw-bold"
                  style={{
                    backgroundColor: "black",
                    padding: "8px 12px",
                    border: "1px solid black",
                    
                  }}
                  data-bs-toggle="modal"
                  data-bs-target="#staticBackdrop"
                >
                  <span style={{ color: "white" ,}}>Logout</span>
                </button>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div
        class="modal fade"
        id="staticBackdrop"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        tabindex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="staticBackdropLabel">
                Logout
              </h1>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">Hello {user}!!, <br/>
              Are you sure you want to Logout?</div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-outline-success"
                data-bs-dismiss="modal"
              >
                Cancel
              </button>
              <button
                type="button"
                class="btn btn-outline-danger"
                onClick={handleLogout}
                data-bs-dismiss="modal"
              >
                Yes
              </button>
            </div>
          </div>
        </div>
      </div>
      <Outlet />
    </div>
  );
};

export default CandidateNavbar
