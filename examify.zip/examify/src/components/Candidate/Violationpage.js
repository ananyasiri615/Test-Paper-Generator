import React from 'react';
import './ViolationPage.css';
import { Navigate, useNavigate } from "react-router-dom";
import Logout from './Logout';

function ViolationPage() {
  const token = localStorage.getItem("username")
  const navigate = useNavigate();
  if(!token){
    return <Navigate to = "/Login"/>
  }
  return (
    <>
    <Logout/>
    <div className="violation-container">
      <div className="violation-card">
        <div className="violation-header">
          <h2 className="heading1" style={{paddingLeft:"60px"}}>Test Violation Detected</h2>
        </div>
        <div className="violation-content">
          <p className="para1">You have violated the test rules, and your test has not been submitted.</p>
          <p className="para1">Please contact the test administrator for further instructions.</p>
          <p className="para1">You can Log out now</p>
        </div>
      </div>
    </div>
    </>
  );
}

export default ViolationPage;
