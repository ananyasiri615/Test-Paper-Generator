import React, { useRef, useEffect } from 'react';

const VideoDisplay = ({ isTestSubmitted }) => {
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  useEffect(() => {
    if (isTestSubmitted) {
      if (streamRef.current) {
        const tracks = streamRef.current.getTracks();
        tracks.forEach((track) => track.stop());
      }
    }
  }, [isTestSubmitted]);

  return (
    <video ref={videoRef} autoPlay playsInline muted style={{ maxWidth: '10%' }}></video>
  );
};

export default VideoDisplay;
