import React, { useEffect, useState } from "react";
import "./TestPaperHistory.css";
import { Navigate, useNavigate } from "react-router-dom";

function TestPaperHistory() {
  const [testHistoryDetails, setTestHistoryDetails] = useState([]);
  const [username, setUsername] = useState("");
  const [totalMarks, setTotalMarks] = useState("");
  const [buttonClicked, setButtonClicked] = useState(false);
  const token = localStorage.getItem("username")
  const navigate = useNavigate();

  useEffect(() => {
    const storedUsername = localStorage.getItem("username");
    setUsername(storedUsername);

    const storedTotalMarks = localStorage.getItem("totalMarks");
    setTotalMarks(storedTotalMarks);

    sendUserAnswersToServer();
    getTestHistoryByUsername();
    setButtonClicked(true);
  }, []); 

  const sendUserAnswersToServer = () => {
    console.log("Sending user answers to the server...");
    const storedUsername = localStorage.getItem("username");
    const storedTotalMarks = localStorage.getItem("totalMarks");

    // Retrieve userAnswers from local storage
    const storedUserAnswers = JSON.parse(localStorage.getItem("userAnswers"));
    console.log("Stored user answers:", storedUserAnswers);

    if (storedUserAnswers && Array.isArray(storedUserAnswers.userAnswers)) {
      setUsername(storedUsername);
      setTotalMarks(storedTotalMarks);
      console.log("User answers are valid.");

      // Build the testPaperData array
      const formattedData = storedUserAnswers.userAnswers.map(
        (userAnswer, index) => {
          const transformedData = {
            chosenAnswer: userAnswer.chosenAnswer,
            question: {
              q_id: userAnswer.question.q_id,
              level: userAnswer.question.level,
            },
            totalMarks: storedTotalMarks,
            username: storedUsername,
          };

          console.log(`Transformed Data ${index + 1}:`, transformedData);

          return transformedData;
        }
      );

      console.log(
        "JSON Body to Send:",
        JSON.stringify({ testpapers: formattedData })
      );

      // Send the formatted data to the server
      fetch("http://localhost:8081/testHistory/createTestHistoryList", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          testpapers: formattedData,
        }),
      })
        .then((response) => {
          if (response.ok) {
            console.log("User answers sent successfully");
            // Optionally, you can remove the userAnswers data if needed.
            // localStorage.removeItem('userAnswers');
          } else {
            console.error("Failed to send user answers to the server");
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    }
    setButtonClicked(true);
  };

  const getTestHistoryByUsername = () => {
    const storedUsername = localStorage.getItem("username");

    if (storedUsername) {
      fetch(`http://localhost:8081/testHistory/byUsername/${storedUsername}`)
        .then((response) => {
          if (response.ok) {
            return response.json();
          } else {
            console.error("Failed to fetch test history");
          }
        })
        .then((data) => {
          setTestHistoryDetails(data);
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    } else {
      console.error("Username not found in local storage");
    }
  };


  const scrollToEnd = () => {
    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: 'smooth',
    });
  };
  const generateReview = (historyData) => {
    let review = "Your performance in the test is as follows:\n\n";
    let level1Correct = 0;
    let level2Correct = 0;
    let level3Correct = 0;

    historyData.forEach((history) => {
      if (history.correct_option === history.chosenAnswer) {
        if (history.level === 1) {
          level1Correct++;
        } else if (history.level === 2) {
          level2Correct++;
        } else if (history.level === 3) {
          level3Correct++;
        }
      }
    });
    const levelPerformance = {
      Level1:
        level1Correct /
        historyData.filter((history) => history.level === 1).length,
      Level2:
        level2Correct /
        historyData.filter((history) => history.level === 2).length,
      Level3:
        level3Correct /
        historyData.filter((history) => history.level === 3).length,
    };
    const sortedLevels = Object.keys(levelPerformance).sort(
      (a, b) => levelPerformance[b] - levelPerformance[a]
    );

    const bestLevel = sortedLevels[0];
    const worstLevel = sortedLevels[sortedLevels.length - 1];

    let suggestions = "";
    if (bestLevel === worstLevel) {
      suggestions = `You have consistently performed at ${bestLevel}. Keep up the good work!`;
    } else {
      suggestions = `You performed best in ${bestLevel} questions and should focus on improving your accuracy in ${worstLevel} questions.`;
    }

    return suggestions;
  };
  if(!token){
    return <Navigate to = "/Login"/>
  }
  return (
    <>
      <div className="incontainer">
        <h2 style={{paddingTop:"30px",paddingLeft:"50px"}}>Hello, {username}</h2>

        {testHistoryDetails.map((history) => (
          <div key={history.history_id} className="container">
            Actual Question: {history.question_name}
            <br />
            Level: {history.level}
            <br />
            Chosen Answer: {history.chosenAnswer}
            <br />
            Correct Option: {history.correct_option}
            <br />
          </div>
        ))}

        {testHistoryDetails.length > 0 && (
          <div className="review-container" style={{width:"900px",marginLeft:"100px",height:"100px",marginBottom:"100px"}}>
            <h4>Review: </h4>
            <p>{generateReview(testHistoryDetails)}</p>
          </div>
        )}
      </div>
      <div className="scroll-to-end-container">
        <button className="scroll-to-end-button" onClick={scrollToEnd} style={{backgroundColor:"black"}}>
          View Review
        </button>
      </div>
    </>
  );
}

export default TestPaperHistory;
