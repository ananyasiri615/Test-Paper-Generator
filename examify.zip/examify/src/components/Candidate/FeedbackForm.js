import React, { useState, useEffect } from 'react';
import './FeedbackForm.css'; 
import Rating from 'react-rating-stars-component';
import { Navigate, useNavigate } from "react-router-dom";

function FeedbackForm() {
  const [platformFeedback, setPlatformFeedback] = useState('');
  const [examFeedback, setExamFeedback] = useState('');
  const [platformRating, setPlatformRating] = useState(0);
  const [examRating, setExamRating] = useState(0);
  const [username, setUsername] = useState('');
  const token = localStorage.getItem("username")
  const navigate = useNavigate();
  useEffect(() => {
    const storedUsername = localStorage.getItem('username');
    if (storedUsername) {
      setUsername(storedUsername);
    }
  }, []);

  const handleSubmit = () => {
    const feedbackData = {
      username: username,
      examFeedback: examFeedback,
      platformFeedback: platformFeedback,
      platformratings: platformRating,
      examRatings: examRating,
    };

    fetch('http://localhost:8081/feedback/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(feedbackData),
    })
      .then((response) => {
        if (response.status === 200) {
          console.log('Feedback submitted successfully');
        } else {
          console.error('Error submitting feedback');
        }
      })
      .catch((error) => {
        console.error('Error submitting feedback:', error);
      });
      navigate("/TestPaperHistory");
  };
  if(!token){
    return <Navigate to = "/Login"/>
  }
  return (
    <div className="feedback-form-backcontainer" style={{ backgroundImage: `url(${process.env.PUBLIC_URL}/Feedback.jpg)`, backgroundSize: 'cover' }}>
      <div className="feedback-form-container">
        <h3 style={{marginTop:"10px",marginLeft:"70px",marginBottom:"20px"}}>Feedback Form</h3>
        <div className="form-group">
          <label>Platform Feedback:</label>
          <textarea
            value={platformFeedback}
            onChange={(e) => setPlatformFeedback(e.target.value)}
          />
          <label>Platform Rating:</label>
          <Rating
            count={5}
            onChange={(rating) => setPlatformRating(rating)}
            value={platformRating}
            size={30}
            activeColor="#FFD700"
          />
        </div>

        <div className="form-group">
          <label>Exam Feedback:</label>
          <textarea
            value={examFeedback}
            onChange={(e) => setExamFeedback(e.target.value)}
          />
          <label>Exam Rating:</label>
          <Rating
            count={5}
            onChange={(rating) => setExamRating(rating)}
            value={examRating}
            size={30}
            activeColor="#FFD700"
          />
        </div>
        {/* <Link to="/TestPaperHistory"> */}
          <button onClick={handleSubmit} className="submit-button">
            Submit
          </button>
        {/* </Link> */}
      </div>
    </div>
  );
}

export default FeedbackForm;
