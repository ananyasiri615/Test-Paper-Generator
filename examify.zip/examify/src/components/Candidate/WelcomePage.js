// import React, { useEffect, useState } from "react";
// import { Navigate, useNavigate } from "react-router-dom";
// import workingGirl from "./images/working-girl.png"
// import './WelcomePage.css';

// const WelcomePage = () => {
//   const [username, SetUsername] = useState("");
//   const token = localStorage.getItem("username")
//   const navigate = useNavigate();

//   useEffect(() => {
//     const storedUsername = localStorage.getItem("username");
//     SetUsername(storedUsername);
//   }, []);
//   if(!token){
//     return <Navigate to = "/Login"/>
//   }
//   return (
//     <div className='container1'>
//       <div className="hero-container1 container1" style={{background: "transparent", boxShadow:"none",paddingRight:"100px"}}>
//         <div className="hero_detail-box">
//           <h3>
//             Hello {username}!! <br />
//             Are You Ready??
//           </h3>
//           <div className="hero_btn-container1">
//             <a href="/InstructionsAccess" className="call_to-btn btn_white-border">
//               Start Test
//             </a>
//             <a href="/TestPaperHistory" className="call_to-btn btn_white-border" style={{marginLeft:"20px"}}>
//               History
//             </a>
//           </div>
//         </div>
//         <div className="hero_img-container1" style={{marginLeft:"400px"}}>
//           <div>
//             <img src={workingGirl} alt="" className="img-fluid"/>
//           </div>
//         </div>
//       </div>
//       </div>
//   )
// }
// export default WelcomePage

import React, { useEffect, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import workingGirl from "./images/working-girl.png"
import './WelcomePage.css';

const WelcomePage = () => {
  const [username, SetUsername] = useState("");
  const token = localStorage.getItem("username")
  const navigate = useNavigate();

  useEffect(() => {
    const storedUsername = localStorage.getItem("username");
    SetUsername(storedUsername);
  }, []);
  if(!token){
    return <Navigate to = "/Login"/>
  }
  return (
    <div className='container1'>
      <div className="hero-container1 container1" style={{background: "transparent", boxShadow:"none"}}>
        <div className="hero_detail-box">
          <h1>
            Hello {username}!!
            Are You Ready??
          </h1>
          <div className="hero_btn-container1">
            <a href="/InstructionsAccess" className="call_to-btn btn_white-border">
              Start Test
            </a>
            <a href="/TestPaperHistory" className="call_to-btn btn_white-border" style={{marginLeft:"20px"}}>
              History
            </a>
          </div>
        </div>
        <div className="hero_img-container1">
          <div>
            <img src={workingGirl} alt="" className="img-fluid"/>
          </div>
        </div>
      </div>
      </div>
  )
}
export default WelcomePage