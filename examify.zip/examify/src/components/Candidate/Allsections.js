
import React, { useState, useEffect, useRef } from 'react';
import { Link, useParams } from 'react-router-dom';
import './Allsections.css';
import { Navigate, useNavigate } from "react-router-dom";

const Allsections = () => {
  const { cameraPermission, microphonePermission } = useParams();

  const [isButtonDisabled, setIsButtonDisabled] = useState(false);

  const [videoStream, setVideoStream] = useState(null);

  const videoRef = useRef(null);
  const token = localStorage.getItem("username")
  const navigate = useNavigate();

  useEffect(() => {
    navigator.permissions.query({ name: 'camera' }).then((permission) => {
      if (permission.state === 'denied') {
        setIsButtonDisabled(true);
      }
    });

    navigator.permissions.query({ name: 'microphone' }).then((permission) => {
      if (permission.state === 'denied') {
        setIsButtonDisabled(true);
        navigate("/Instructionaccess");
      }
    });
  }, [cameraPermission, microphonePermission]);

  useEffect(() => {
    if (!videoStream) {
      navigator.mediaDevices.getUserMedia({ video: true })
        .then((stream) => {
          setVideoStream(stream);
        })
        .catch((error) => {
          console.error(error);
        });
    }
  }, [cameraPermission]);

  useEffect(() => {
    if (!videoStream) {
      navigator.mediaDevices
        .getUserMedia({ video: true })
        .then((stream) => {
          setVideoStream(stream);
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        })
        .catch((error) => {
          console.error(error);
        });
    }

    return () => {
      if (videoStream) {
        videoStream.getTracks().forEach((track) => {
          track.stop();
        });
      }
    };
  }, [videoStream]);

  const handleAttemptClick = () => {
    if (cameraPermission === "granted" && microphonePermission === "granted") {
      navigate(`/Testpaper/${cameraPermission}/${microphonePermission}`);
    } else {
      
    }
  };

  if(!token){
    return <Navigate to = "/Login"/>
  }
  
  return (
    <div className="wrapper" style={{ backgroundColor: "white"}}>
      <div className="allsections-container">
        <h2 style={{paddingLeft:"140px"}}>Testpaper Details</h2>

        <div>
          <div className="section-info">
            <p  style={{color:"black"}}>40 Questions</p>
            <p  style={{color:"black"}}>Time 1 hour</p>
          </div>
          <p  style={{color:"black"}}>
            This Testpaper contains 40 MCQs of different levels, Level 1 - easy, Level 2 - medium, Level 3 - difficult, and the time allowed is 1 hour. You have to attempt all the questions.
          </p><br />
          <p  style={{color:"black"}}>
            If you want to flag any questions, you can click on the flag button next to the question and recheck the question again. Once you have understood this section, click the "Attempt Now" button to navigate to the test paper. When you click the "Attempt Now" button, the timer will start, and the test will be auto-submitted when the timer ends.
          </p>
          <video ref={videoRef} autoPlay playsInline muted srcObject={videoStream} />
          <div
            style={{
              position: "fixed",
              bottom: 0,
              right: 0,
              margin: "20px",
              maxWidth: "300px",
              maxHeight: "1000px",
            }}
          >
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              style={{ width: "100%", maxWidth: "600px" }}
            />
          </div>{" "}
            <button
              onClick={handleAttemptClick}
              disabled={isButtonDisabled}
              className={isButtonDisabled ? 'disabled' : ''}
              style={{marginLeft:"60px",marginBottom:"80px"}}
            >
              {isButtonDisabled ? 'Camera and microphone permissions required' : 'Attempt Now'}
            </button>
        </div>
      </div>
    </div>
  );
};

export default Allsections;



















// import React, { useState, useEffect, useRef } from 'react';
// import { Link, useParams } from 'react-router-dom';
// import './Allsections.css';
// import { Navigate, useNavigate } from "react-router-dom";

// const Allsections = () => {
//   const { cameraPermission, microphonePermission } = useParams();

//   const [isButtonDisabled, setIsButtonDisabled] = useState(false);

//   const [videoStream, setVideoStream] = useState(null);

//   const videoRef = useRef();
//   const token = localStorage.getItem("username")
//   const navigate = useNavigate();

//   useEffect(() => {
//     navigator.permissions.query({ name: 'camera' }).then((permission) => {
//       if (permission.state === 'denied') {
//         setIsButtonDisabled(true);
//       }
//     });

//     navigator.permissions.query({ name: 'microphone' }).then((permission) => {
//       if (permission.state === 'denied') {
//         setIsButtonDisabled(true);
//         navigate("/Instructionaccess");
//       }
//     });
//   }, [cameraPermission, microphonePermission]);

//   useEffect(() => {
//     if (!videoStream) {
//       navigator.mediaDevices.getUserMedia({ video: true })
//         .then((stream) => {
//           setVideoStream(stream);
//         })
//         .catch((error) => {
//           console.error(error);
//         });
//     }
//   }, [cameraPermission]);

//   const handleAttemptClick = () => {
//     if (cameraPermission === 'granted' && microphonePermission === 'granted') {
//        navigate(`/Testpaper/${cameraPermission}/${microphonePermission}`)
//     } else {
    
//     }
//   };
//   if(!token){
//     return <Navigate to = "/Login"/>
//   }
  
//   return (
//     <div className="wrapper" style={{ backgroundColor: "white"}}>
//       <div className="allsections-container">
//         <h2 style={{paddingLeft:"140px"}}>Testpaper Details</h2>

//         <div>
//           <div className="section-info">
//             <p  style={{color:"black"}}>40 Questions</p>
//             <p  style={{color:"black"}}>Time 1 hour</p>
//           </div>
//           <p  style={{color:"black"}}>
//             This Testpaper contains 40 MCQs of different levels, Level 1 - easy, Level 2 - medium, Level 3 - difficult, and the time allowed is 1 hour. You have to attempt all the questions.
//           </p><br />
//           <p  style={{color:"black"}}>
//             If you want to flag any questions, you can click on the flag button next to the question and recheck the question again. Once you have understood this section, click the "Attempt Now" button to navigate to the test paper. When you click the "Attempt Now" button, the timer will start, and the test will be auto-submitted when the timer ends.
//           </p>
//           <video ref={videoRef} autoPlay playsInline muted srcObject={videoStream} />
//             <button
//               onClick={handleAttemptClick}
//               disabled={isButtonDisabled}
//               className={isButtonDisabled ? 'disabled' : ''}
//               style={{marginLeft:"60px",marginBottom:"80px"}}
//             >
//               {isButtonDisabled ? 'Camera and microphone permissions required' : 'Attempt Now'}
//             </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Allsections;


