import React, { useState, useEffect, useRef } from 'react';

import { Link } from 'react-router-dom';
import axios from 'axios';
import InstructionsAccess from './InstructionsAccess';
import './Testpaper.css';
import useHistory from 'react-router-dom'
import { Navigate, useNavigate } from "react-router-dom";
import { useParams } from 'react-router-dom';

let myTrialArr = [];

function Testpaper() {
  const [sections, setSections] = useState([]);
  const [selectedSection, setSelectedSection] = useState(null);
  const [isTestSubmitted, setIsTestSubmitted] = useState(false);
  // const [updatedSection, setUpdatedSection] = useState({});
  const [isEditing, setIsEditing] = useState(false);
  const [generatedSection, setGeneratedSection] = useState(null);
  const [subjectId, setSubjectId] = useState(1);
  const [numberOfQuestions, setNumberOfQuestions] = useState(10);
  const [generatedQuestions, setGeneratedQuestions] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState({});
  const [sectionTimer, setSectionTimer] = useState(3000); 
  const [isTestActive, setIsTestActive] = useState(false);
  const [attemptedSections, setAttemptedSections] = useState([]);
  const formRef = useRef();
  const [tabSwitchCount, setTabSwitchCount] = useState(0);
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [subjectIds, setSubjectIds] = useState([]);
  const [generatedSections, setGeneratedSections] = useState([]);
  const[totalMarks,setTotalMarks] = useState();
  const [allGeneratedQuestions, setAllGeneratedQuestions] = useState([]);
  const [isSubmitClicked, setIsSubmitClicked] = useState(false);
  const [isStartClicked, setIsStartClicked] = useState(false);
  const [timerInterval, setTimerInterval] = useState(null);
  const [isButtonClicked, setIsButtonClicked] = useState(false);
  const [flagButtonStates, setFlagButtonStates] = useState({});
  const [questionFlags, setQuestionFlags] = useState({});
  const [isStartButtonDisabled, setIsStartButtonDisabled] = useState(false);
  const [isStartButtonClicked, setIsStartButtonClicked] = useState(false);
  const { cameraPermission, microphonePermission } = useParams();
  const [isDivDisabled, setIsDivDisabled] = useState(false);
  const [videoStream, setVideoStream] = useState(null);
  const videoRef = useRef(null);
  const [startTime, setStartTime] = useState(null);
  const [endTime, setEndTime] = useState(null);

  const handleDisableClick = () => {
    setIsDivDisabled(true);
  }

  const token = localStorage.getItem("username")
  const navigate = useNavigate();
  const [totalpapermarks, setTotalpaperMarks] = useState();
    useEffect(() => {
    if (!videoStream) {
      navigator.mediaDevices
        .getUserMedia({ video: true })
        .then((stream) => {
          setVideoStream(stream);
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        })
        .catch((error) => {
          console.error(error);
        });
    }

    return () => {
      if (videoStream) {
        videoStream.getTracks().forEach((track) => {
          track.stop();
        });
      }
    };
  }, [videoStream]);
  
  useEffect(() => {
    if ('Notification' in window && Notification.permission !== 'granted') {
      Notification.requestPermission().then((permission) => {
        if (permission === 'granted') {
          console.log('Notification permission granted.');
        }
      });
    }
  }, []);
  useEffect(() => {
    navigator.permissions.query({ name: 'camera' }).then((cameraPermission) => {
      if (cameraPermission.state === 'denied') {
        setIsButtonDisabled(true);
        navigate('/ViolationPage');
      }
    });

    navigator.permissions.query({ name: 'microphone' }).then((microphonePermission) => {
      if (microphonePermission.state === 'denied') {
        setIsButtonDisabled(true);
        navigate('/ViolationPage');
      }
    });
  }, []);
  
  useEffect(() => {
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
      } else {
        Notification.requestPermission().then((permission) => {
          if (permission === 'granted') {
          }
        });
      }
    } else {
      console.error('Notification API is not supported in this browser.');
    }
  }, []);
  useEffect(() => {
    // Calculate and set totalTestTimeInSeconds based on startTime and endTime
    const totalTestTimeInSeconds = startTime && endTime ? Math.floor((endTime - startTime) / 1000) : null;
    localStorage.setItem('totalTestTimeInSeconds', totalTestTimeInSeconds);
  }, [startTime, endTime]);
  useEffect(() => {
    setGeneratedSections([]);
    setAllGeneratedQuestions([]);
    setSelectedOptions({});
  }, []);
  const handleClick = () => {
    setIsButtonClicked(true);
  };
  useEffect(() => {
    // Set the start time in local storage when the test starts
    if (isStartButtonClicked) {
      const startTime = new Date();
      localStorage.setItem('startTime', startTime.toISOString());
      setStartTime(startTime);
    }
  }, [isStartButtonClicked]);

  useEffect(() => {
    // Set the end time in local storage when the test ends
    if (isSubmitClicked) {
      const endTime = new Date();
      localStorage.setItem('endTime', endTime.toISOString());
      setEndTime(endTime);
    }
  }, [isSubmitClicked]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setTabSwitchCount((prevCount) => prevCount + 1);
        if (tabSwitchCount  === 1) { 
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('Warning', {
              body: 'You switched tabs. Switching again will submit the test automatically.',
            });
          }
        }
      }
    };
    
  
    document.addEventListener('visibilitychange', handleVisibilityChange);
  
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [tabSwitchCount]);

  const handleAttemptClick = () => {
    if (cameraPermission === 'granted' && microphonePermission === 'granted') {
      setIsButtonDisabled(true);
     
    } 
  };
  
  useEffect(() => {
    const handleBeforeUnload = (event) => {
      if (isStartButtonClicked) {
        event.preventDefault();
        submitUserAnswers();
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isStartButtonClicked]);
  
  
  useEffect(() => {
    if (tabSwitchCount === 1) {
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Warning', {
          body: 'You switched tabs. Switching again will submit the test automatically.',
        });
      }
  
      const countdownTime = 1;
      let timeLeft = countdownTime;
  
      const countdownInterval = setInterval(() => {
        if (timeLeft === 0) {
          setEndTime(new Date());
          submitUserAnswers();
          clearInterval(countdownInterval);
        }
        timeLeft -= 1;
      }, 1000);
    }
  }, [tabSwitchCount]);
    
  const stopVideo = () => {
    if (videoRef.current) {
      const videoElement = videoRef.current;
      videoElement.srcObject = null;
    }
  };
  useEffect(() => {
    axios.get('http://localhost:8081/sections/all')
      .then((response) => {
        setSections(response.data);
      })
      .catch((error) => {
        console.error('Error fetching sections:', error);
      });
  }, []);
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setTabSwitchCount((prevCount) => prevCount + 1);
      }
    };
  
    document.addEventListener('visibilitychange', handleVisibilityChange);
  
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);
  
  useEffect(() => {
    axios.get('http://localhost:8081/subjects/all')
      .then((response) => {
        const ids = response.data.map((subject) => subject.subjectId);
        setSubjectIds(ids);
      })
      .catch((error) => {
        console.error('Error fetching subject IDs:', error);
      });
  }, []);
  useEffect(() => {
    if (tabSwitchCount > 1) {
      submitUserAnswers();
    }
  }, [tabSwitchCount]);
  
  const buildUserAnswersJson = () => {
    const userAnswers = [];
  
    for (const section of generatedSections) {
      for (const question of section.questions) {
        userAnswers.push({
          question: {
            q_id: question.q_id,
            level: question.level,
          },
          chosenAnswer: selectedOptions[question.q_id] || '',
          flagged: question.reported || false,
        });
      }
    }
  
    return {
      userAnswers,
    };
  };
  
  
  

  const submitUserAnswers = async () => {
    try {
      const userAnswersJson = buildUserAnswersJson();
      console.log("Answers by candidate:", userAnswersJson);
  
      let totalMarks = 0;
      let totalPaperMarks = 0;
  
      for (const userAnswer of userAnswersJson.userAnswers) {
        const level = userAnswer.question.level;
        if (level === 1) {
          totalMarks += 1;
        } else if (level === 2) {
          totalMarks += 2;
        } else if (level === 3) {
          totalMarks += 3;
        }
      }
  
      const response = await axios.post('http://localhost:8081/useranswer/gettotal', userAnswersJson, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      if (response.status === 200) {
        const totalMarksss = response.data.totalMarks;
        console.log('Submit Response - Total Marks:', totalMarksss);
        console.log(userAnswersJson);
        setTotalMarks(totalMarksss);
        setTotalpaperMarks(totalMarks);
  
        localStorage.setItem('totalMarks', totalMarksss);
        localStorage.setItem('userAnswers', JSON.stringify(userAnswersJson));
        localStorage.setItem('flaggedQuestions', JSON.stringify(generatedQuestions.filter((question) => question.reported)));
  
        navigate(`/Report/${totalMarksss}/${totalMarks}`);
      } else {
        console.error('Error: Unexpected response status');
      }
    } catch (error) {
      console.error('Error submitting user answers:', error);
    }
  };
  
  
  
  const attemptSubjects = async () => {
    const generatedSectionsCopy = [];

    for (const subjectIdToAttempt of subjectIds) {
      try {
        const response = await axios.post(
          `http://localhost:8081/sections/generate?subjectId=${subjectIdToAttempt}&numberOfQuestions=${numberOfQuestions}`
        );
        const generatedSection = response.data;
        generatedSectionsCopy.push(generatedSection);
        myTrialArr = generatedSection.questions;
        console.log("Generated Section:- ", myTrialArr);

        const newGeneratedQuestions = [...allGeneratedQuestions, ...generatedSection.questions];
        setAllGeneratedQuestions(newGeneratedQuestions);
        setGeneratedSections(generatedSectionsCopy);
        localStorage.setItem('generatedQuestions', JSON.stringify(newGeneratedQuestions));
        setIsTestActive(true); 

      } catch (error) {
        console.error('Error generating a random section:', error);
      }
    }
  };
  const toggleFlag = (questionId) => {
    setQuestionFlags((prevFlags) => ({
      ...prevFlags,
      [questionId]: !prevFlags[questionId],
    }));
  };
  useEffect(() => {
    const storedAttemptedSections = JSON.parse(localStorage.getItem('attemptedSections'));
    if (storedAttemptedSections) {
      setAttemptedSections(storedAttemptedSections);
    }
  }, []);
  const startSectionTimer = (initialTime) => {
    setSectionTimer(initialTime);
    const intervalId = setInterval(() => {
      setSectionTimer((prevTime) => {
        if (prevTime > 0) {
          return prevTime - 1;
        }
        clearInterval(intervalId);
        if (formRef.current && !isSubmitClicked) {
          submitUserAnswers(); 
        }
        return 0;
      });
      console.log('Timer Updated:', sectionTimer);
    }, 1000); 
    setTimerInterval(intervalId); 
  };

  const toggleFlagQuestion = (questionId) => {
    const updatedQuestions = generatedQuestions.map((question) => {
      if (question.q_id === questionId) {
        const updatedQuestion = {
          ...question,
          reported: !question.reported,
        };
        setFlagButtonStates({
          ...flagButtonStates,
          [questionId]: updatedQuestion.reported,
        });

        return updatedQuestion;
      }
      return question;
    });

    setGeneratedQuestions(updatedQuestions);
    setSelectedOptions({
      ...selectedOptions,
      [questionId]: '', 
    });
    localStorage.setItem('generatedQuestions', JSON.stringify(updatedQuestions));
  };
  

  
  
  useEffect(() => {
    const storedGeneratedQuestions = JSON.parse(localStorage.getItem('generatedQuestions'));
    if (storedGeneratedQuestions) {
      setGeneratedQuestions(storedGeneratedQuestions);
    }
  }, []);
  const logFlaggedQuestions = () => {
    localStorage.setItem('generatedQuestions', JSON.stringify(generatedQuestions));
    const flaggedQuestions = generatedQuestions.filter((question) => question.reported);

    console.log('Flagged Questions:');
    flaggedQuestions.forEach((question) => {
      console.log(`Question ID: ${question.q_id}`);
      console.log(`Level: ${question.level}`);
      console.log(`Question: ${question.actual_qns}`);
    });
  };

  useEffect(() => {
    const storedGeneratedQuestions = JSON.parse(localStorage.getItem('generatedQuestions'));
    console.log('Stored questions:- ', storedGeneratedQuestions);
    if (storedGeneratedQuestions) {
      setGeneratedQuestions(storedGeneratedQuestions);
    }
  }, []);
  const handleOptionChange = (questionId, selectedOption) => {
    setSelectedOptions({
      ...selectedOptions,
      [questionId]: selectedOption,
    });
  };
  const printSelectedOptions = () => {
    console.log('Selected Options:', selectedOptions);

  };
  

  if(!token){
    return <Navigate to = "/Login"/>
  }

  return (
    
       <div>
      <div className="timer-container">
        <p  style={{color:"black"}}>
          Time Remaining: {Math.floor(sectionTimer / 60)}:{(sectionTimer % 60).toString().padStart(2, '0')}
        </p>
      </div>
      <div>
  <div className="start-button-container">
    <button
      onClick={async () => {
        if (!isStartButtonDisabled) {
          handleAttemptClick();
          setStartTime(new Date());
          attemptSubjects();
          setIsStartButtonClicked(true);
          setIsStartButtonDisabled(true);
          if (sectionTimer === 0) {
            submitUserAnswers();
          } else {
            startSectionTimer(3000);
          }
        }
      }}
      disabled={isStartButtonDisabled}
      className={`attempt-button ${isStartButtonClicked ? 'start-button-clicked' : ''}`}
      style={{marginTop:"20px"}}
    >
      {isStartButtonClicked ? (
        <div className="disabled-div">
          {/* <p>Test has been started.</p>
          Attempted */}
          <br />
        </div>
      ) : (
        <div className="enabled-div">
          <p style={{color:"black"}}>Are you sure you want to start the test?</p>
          <button style={{margin:"20px",marginLeft:"100px"}}>Start</button>
        </div>
      )}
    </button>
  </div>
</div>

      {generatedSections.length > 0 && (
        <>
      {generatedSections.map((section, sectionIndex) => (
        <div key={section.section_id} className="section-container">
          <h2 style={{paddingLeft:"600px", paddingTop:"10px"}}>Section {sectionIndex + 1}</h2>
          {section.questions.map((question) => (
            <div key={question.q_id} className="question1-container">
              <div key={question.q_id} className={`question-container ${question.reported ? 'flagged' : ''}`}>
              <button
                className={`flag-button ${questionFlags[question.q_id] ? 'flagged' : ''}`}
                onClick={() => toggleFlag(question.q_id)}
              >
                {questionFlags[question.q_id] ? 'Unflag' : 'Flag'}
              </button>
                  
              <br />
              <p style={{color:"black"}}>Level: {question.level}</p>
              <p style={{color:"black"}}>Question: {question.actual_qns}</p>
        <form>
          <label className="radio-label">
            <input
              type="radio"
              name={`question_${question.q_id}`}
              value={question.option1}
              checked={selectedOptions[question.q_id] === question.option1}
              onChange={() => handleOptionChange(question.q_id, question.option1)}
            />
               <span className="radio-option-text">{question.option1}</span>
          </label>
          <br />
          <label className="radio-label">
            <input
              type="radio"
              name={`question_${question.q_id}`}
              value={question.option2}
              checked={selectedOptions[question.q_id] === question.option2}
              onChange={() => handleOptionChange(question.q_id, question.option2)}
            />
            {question.option2}
          </label>
          <br />
          <label className="radio-label">
            <input
              type="radio"
              name={`question_${question.q_id}`}
              value={question.option3}
              checked={selectedOptions[question.q_id] === question.option3}
              onChange={() => handleOptionChange(question.q_id, question.option3)}
            />
                  {question.option3}
          </label>
          <br />
          <label className="radio-label">
            <input
              type="radio"
              name={`question_${question.q_id}`}
              value={question.option4}
              checked={selectedOptions[question.q_id] === question.option4}
              onChange={() => handleOptionChange(question.q_id, question.option4)}
            />
             {question.option4}
          </label>
        </form>
        
        </div>
        </div>
    ))}
   
  </div>
))}

<div>
<button 
          onClick={() => {
            printSelectedOptions();
            logFlaggedQuestions();
            submitUserAnswers();
            setIsSubmitClicked(true);
            stopVideo();
            setEndTime(new Date());

          }}
          className={`submit-button ${isSubmitClicked ? 'clicked' : ''}`}
          style={{margin:"10px"}}
        >
          {isSubmitClicked ? 'Attempted' : 'Submit'}
        </button>
      </div>
      </>
      )}
	  <div style={{ position: 'fixed', bottom: 0, right: 0, margin: '20px', maxWidth: '300px',maxHeight: "1000px" }}>
      <video ref={videoRef} autoPlay playsInline muted style={{ width: '100%', maxWidth: '600px' }} />
      </div>
  </div>
  
);
}

export default Testpaper;









