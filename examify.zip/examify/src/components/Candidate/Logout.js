import React, { useState } from 'react';
import { Navigate, useNavigate } from "react-router-dom";

function Logout() {
  const [loginStatus, setLoginStatus] = useState(true);
  const token = localStorage.getItem("username")
  const navigate = useNavigate();

  const logouthandler = () => {
    localStorage.clear();
    setLoginStatus(false);
  };
  if (loginStatus === false) {
    return <Navigate to="/" />;
  }
  if(!token){
    return <Navigate to = "/Login"/>
  }

  return (
    <nav className="navbar" style={{backgroundColor:"lightGray"}}>
      
      <div className="navbar-right" style={{paddingRight:"8px",marginLeft:"1250px"}}>
      <button className="logout-button" onClick={logouthandler} >Logout</button>
      </div>
    </nav>
  );
}

export default Logout;
