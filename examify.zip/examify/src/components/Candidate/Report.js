import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import { Navigate, useNavigate } from "react-router-dom";
import "./Report.css";

function calculateGrade(totalMarks, totalTestPaperMarks) {
  let percentage = (totalMarks / totalTestPaperMarks) * 100;
  if (percentage >= 80) {
    return "Congragulations for scoring A+";
  } else if (percentage >= 60) {
    return "A";
  } else if (percentage >= 40) {
    return "B";
  } else {
    return "C";
  }
}

function Report() {
  const { totalMarks, totalTestPaperMarks } = useParams();
  const [username, setUsername] = useState("");
  const [hasReattempted, setHasReattempted] = useState(
    localStorage.getItem("hasReattempted") === "true"
  );
  const [startDate, setStartDate] = useState(
    localStorage.getItem("startDate") || ""
  );
  const [endDate, setEndDate] = useState(localStorage.getItem("endDate") || "");
  const token = localStorage.getItem("username");
  const navigate = useNavigate();
  useEffect(() => {
    const storedUsername = localStorage.getItem("username");
    if (storedUsername) {
      setUsername(storedUsername);
    }
  }, []);
  const currentDate = new Date();

  const formattedDate = currentDate.toISOString().split("T")[0];

  localStorage.setItem("currentDate", formattedDate);
  const handleReattemptClick = () => {
    if (!hasReattempted) {
      setHasReattempted(true);
      localStorage.setItem("hasReattempted", "true");
      navigate("/testpaper");
    }

    console.log("hasReattempted after click:", hasReattempted);
  };

  const grade = calculateGrade(
    parseInt(totalMarks),
    parseInt(totalTestPaperMarks)
  );
  const handleFinishClick = () => {
    const currentDate = new Date();
    const storedStartTime = localStorage.getItem("startTime");
    const formattedDate = currentDate.toISOString().split("T")[0];

    localStorage.setItem("currentDate", formattedDate);
    const startDateTime = new Date(storedStartTime);
    const startHours = startDateTime.getHours();
    const startMinutes = startDateTime.getMinutes();
    const startSeconds = startDateTime.getSeconds();

    const endHours = currentDate.getHours();
    const endMinutes = currentDate.getMinutes();
    const endSeconds = currentDate.getSeconds();

    const startTimeFormatted = `${startHours}:${startMinutes}:${startSeconds}`;
    const endTimeFormatted = `${endHours}:${endMinutes}:${endSeconds}`;
    const data = {
      username: username,
      totalscore: parseInt(totalMarks),
      startTime: startTimeFormatted,
      endTime: endTimeFormatted,
      grade: calculateGrade(
        parseInt(totalMarks),
        parseInt(totalTestPaperMarks)
      ),
      date: formattedDate,
    };

    fetch("http://localhost:8081/candidatehistory/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((response) => response.json())
      .then((result) => {
        console.log("POST request result:", result);
        navigate("/FeedbackForm");
        window.location.reload();
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };
  if (!token) {
    return <Navigate to="/Login" />;
  }

  return (
    <div
      className="bodyy"
      style={{
        backgroundImage: `url(${process.env.PUBLIC_URL}/bg1.jpg)`,
        backgroundSize: "cover",
      }}
    >
      <div className="report-container">
        <h1 className="report-title">
          Hello {username}, You scored {totalMarks} marks
        </h1>
        <h2 className="grade">Your grade: {grade}</h2>
        {grade === "C" ? (
          <button
            className={`reattempt-button ${hasReattempted ? "disabled" : ""}`}
            onClick={handleReattemptClick}
            disabled={hasReattempted}
          >
            Reattempt
          </button>
        ) : (
          <p className="reattempt-disabled">
            Reattempt is only available for grade C.
          </p>
        )}
        {/* <Link to="/FeedbackForm"> */}
          <button className="finish-button" onClick={handleFinishClick}>
            Finish
          </button>
        {/* </Link> */}
      </div>
    </div>
  );
}

export default Report;
