// import React, { useState, useRef, useEffect } from "react";
// import "./InstructionsAccess.css";
// import VideoDisplay from "./VideoDisplay";
// import { Navigate, useNavigate } from "react-router-dom";

// const InstructionsAccess = () => {
//   const [cameraPermission, setCameraPermission] = useState(null);
//   const [microphonePermission, setMicrophonePermission] = useState(null);
//   const [locationPermission, setLocationPermission] = useState(null);
//   const [isTestSubmitted, setIsTestSubmitted] = useState(false);
//   const videoRef = useRef(null);
//   const streamRef = useRef(null);
//   const [isAgreed, setIsAgreed] = useState(false);
//   const [videoPosition, setVideoPosition] = useState({
//     top: "100px",
//     left: "100px",
//   });
//   const [isVideoMovable, setIsVideoMovable] = useState(false);
//   const [isVideoResizable, setIsVideoResizable] = useState(false);
//   const [isAgreeButtonClicked, setIsAgreeButtonClicked] = useState(false);
//   const token = localStorage.getItem("username")
//   const navigate = useNavigate();

//   const handleAgree = () => {
//     setIsAgreed(true);
//   };
//   const toggleVideoMove = () => {
//     setIsVideoMovable(!isVideoMovable);
//   };

//   const toggleVideoResize = () => {
//     setIsVideoResizable(!isVideoResizable);
//   };

//   const handleVideoDrag = (event) => {
//     if (isVideoMovable) {
//       const videoElement = videoRef.current;
//       videoElement.style.top = event.clientY + "px";
//       videoElement.style.left = event.clientX + "px";
//     }
//   };

//   const handleVideoResize = (event) => {
//     if (isVideoResizable) {
//       const videoElement = videoRef.current;
//       videoElement.style.width = event.clientX + "px";
//       videoElement.style.height = event.clientY + "px";
//     }
//   };
//   const stopCameraAndMicrophone = () => {
//     if (streamRef.current) {
//       const tracks = streamRef.current.getTracks();
//       tracks.forEach((track) => track.stop());
//       videoRef.current.srcObject = null;
//       setCameraPermission(null);
//       setMicrophonePermission(null);
//     }
//   };
//   const requestCameraAndMicrophonePermission = async () => {
//     try {
//       const stream = await navigator.mediaDevices.getUserMedia({
//         video: true,
//         audio: true,
//       });
//       setCameraPermission("granted");
//       setMicrophonePermission("granted");
//       streamRef.current = stream;
//       videoRef.current.srcObject = stream;
//     } catch (error) {
//       console.error("Error accessing camera and microphone:", error);
//       setCameraPermission("denied");
//       setMicrophonePermission("denied");
//     }
//   };
//   const requestLocationPermission = () => {
//     if ("geolocation" in navigator) {
//       navigator.geolocation.getCurrentPosition(
//         (position) => {
//           setLocationPermission("granted");
//           console.log("Latitude:", position.coords.latitude);
//           console.log("Longitude:", position.coords.longitude);
//         },
//         (error) => {
//           console.error("Error accessing location:", error);
//           setLocationPermission("denied");
//         }
//       );
//     } else {
//       console.error("Geolocation not supported in this browser.");
//       setLocationPermission("not-supported");
//     }
//   };
//   const submitTest = () => {
//     setIsTestSubmitted(true);
//   };

//   const allsectionshandler = () => {
//     navigate(`/Allsections/${cameraPermission}/${microphonePermission}`)

//   }
//   useEffect(() => {
//     console.log("cameraPermission:", cameraPermission);
//     console.log("microphonePermission:", microphonePermission);
//   }, [cameraPermission, microphonePermission]);
//   if(!token){
//     return <Navigate to = "/Login"/>
//   }
//   return (
//     <div className="instructions-container">
//       <h2 style={{padding:"10px",paddingLeft:"110px"}}>GUIDELINES TO BE FOLLOWED</h2>
//       <br />
//       <div className="section-info">
//         <p style={{color:"black"}}>Four Sections </p>
//         <p style={{color:"black"}}>40 Questions</p>
//         <p style={{color:"black"}}>Time: 1 hour</p>
//       </div>
//       <p style={{color:"black"}}>
//         Take a deep breath and relax, we have designed this test to be fun,
//         quick, and easy!
//       </p>
//       <h2>Instructions</h2>
//       <ol>
//         <li>
//           It is a time-bound section and should be attempted within the allotted
//           Section time.
//         </li>
//         <li>
//           This section may contain the following types of questions:
//           <ul>
//             <li>Multiple choice</li>
//             <li>Fill in the blanks</li>
//             <li>Logic box</li>
//           </ul>
//           <li>
//             To Continue with test you have to give access to allow your camera
//             microphone and Location
//           </li>
//           <li>No swithcing between tab</li>The exam will be proctored through
//           out the end so do not try to do any malpractice and if any malpractice
//           is caught then your test will not be considered and will be denied to
//           attend any further tests
//         </li>
//       </ol>
//       <div className="buttons">
//         <button
//           onClick={requestCameraAndMicrophonePermission}
//           disabled={
//             cameraPermission === "granted" || microphonePermission === "granted"
//           }
//         >
//           Camera and Microphone
//         </button>

//         <button
//           onClick={requestLocationPermission}
//           disabled={locationPermission === "granted"}
//         >
//           Location
//         </button>
//       </div>
//       <br /> <br /> 
//       <div className="buttons">
//         <p className="ZAZ" style={{marginBottom:"-5px",color:"black"}}>Agree to continue</p>
//         <button
//           className={`agree-button ${isAgreeButtonClicked ? "clicked" : ""}`}
//           onClick={handleAgree}
//         >
//           Agree
//         </button>
//           <button className="disagree-button" onClick={() => navigate("/WelcomePage")}>Disagree</button>
       
//       </div>
//       <div>
//         <VideoDisplay isTestSubmitted={isTestSubmitted} />
//       </div>
//         <button
//           className="start-button"
//           disabled={
//             !isAgreed ||
//             cameraPermission !== "granted" ||
//             microphonePermission !== "granted" ||
//             locationPermission !== "granted"
//           }
//           onClick={allsectionshandler}
//         >
//           Start test
//         </button>
//       <video
//         ref={videoRef}
//         autoPlay
//         playsInline
//         muted
//         style={{ maxWidth: "10%" }}
//       ></video>
//       <div style={{ position: 'fixed', bottom: 0, right: 0, margin: '20px', maxWidth: '300px',maxHeight: "1000px" }}>
//       <video ref={videoRef} autoPlay playsInline muted style={{ width: '100%', maxWidth: '600px' }} />
//       </div>
//     </div>
//   );
// };

// export default InstructionsAccess;
import React, { useState, useRef, useEffect } from "react";
import "./InstructionsAccess.css";
import VideoDisplay from "./VideoDisplay";
import { Navigate, useNavigate } from "react-router-dom";

const InstructionsAccess = () => {
  const [cameraPermission, setCameraPermission] = useState(null);
  const [microphonePermission, setMicrophonePermission] = useState(null);
  const [locationPermission, setLocationPermission] = useState(null);
  const [isTestSubmitted, setIsTestSubmitted] = useState(false);
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [isAgreed, setIsAgreed] = useState(false);
  const [isAgreeButtonClicked, setIsAgreeButtonClicked] = useState(false);
  const token = localStorage.getItem("username");
  const navigate = useNavigate();

  const handleAgree = () => {
    setIsAgreed(true);
  };

  const requestCameraAndMicrophonePermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      setCameraPermission("granted");
      setMicrophonePermission("granted");
      streamRef.current = stream;
      videoRef.current.srcObject = stream;
    } catch (error) {
      console.error("Error accessing camera and microphone:", error);
      setCameraPermission("denied");
      setMicrophonePermission("denied");
    }
  };

  const requestLocationPermission = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocationPermission("granted");
          console.log("Latitude:", position.coords.latitude);
          console.log("Longitude:", position.coords.longitude);
        },
        (error) => {
          console.error("Error accessing location:", error);
          setLocationPermission("denied");
        }
      );
    } else {
      console.error("Geolocation not supported in this browser.");
      setLocationPermission("not-supported");
    }
  };

  const submitTest = () => {
    setIsTestSubmitted(true);
  };

  const allSectionsHandler = () => {
    navigate(`/Allsections/${cameraPermission}/${microphonePermission}`);
  };

  useEffect(() => {
    console.log("cameraPermission:", cameraPermission);
    console.log("microphonePermission:", microphonePermission);
  }, [cameraPermission, microphonePermission]);

  if (!token) {
    return <Navigate to="/Login" />;
  }

  return (
    <div className="instructions-container">
      <h2 style={{ padding: "10px", paddingLeft: "110px" }}>
        GUIDELINES TO BE FOLLOWED
      </h2>
      <br />
      <div className="section-info">
        <p style={{ color: "black" }}>Four Sections </p>
        <p style={{ color: "black" }}>40 Questions</p>
        <p style={{ color: "black" }}>Time: 1 hour</p>
      </div>
      <p style={{ color: "black" }}>
        Take a deep breath and relax, we have designed this test to be fun,
        quick, and easy!
      </p>
      <h2>Instructions</h2>
      <ol>
        <li>
          It is a time-bound section and should be attempted within the allotted
          Section time.
        </li>
        <li>
          This section may contain the following types of questions:
          <ul>
            <li>Multiple choice</li>
            <li>Fill in the blanks</li>
            <li>Logic box</li>
          </ul>
        </li>
        <li>
          To Continue with the test, you have to give access to allow your
          camera, microphone, and Location.
        </li>
        <li>No switching between tabs.</li>
        <li>
          The exam will be proctored throughout, so do not try to do any
          malpractice. If any malpractice is caught, then your test will not be
          considered and will be denied to attend any further tests.
        </li>
      </ol>
      <div className="buttons">
        <button
          onClick={requestCameraAndMicrophonePermission}
          disabled={
            cameraPermission === "granted" || microphonePermission === "granted"
          }
        >
          Request Camera and Microphone
        </button>

        <button
          onClick={requestLocationPermission}
          disabled={locationPermission === "granted"}
        >
          Request Location
        </button>
      </div>
      <br />
      <div className="buttons">
        <p className="ZAZ" style={{ marginBottom: "-5px", color: "black" }}>
          Agree to continue
        </p>
        <button
          className={`agree-button ${
            isAgreeButtonClicked ? "clicked" : ""
          }`}
          onClick={handleAgree}
        >
          Agree
        </button>
        <button
          className="disagree-button"
          onClick={() => navigate("/WelcomePage")}
        >
          Disagree
        </button>
      </div>
      <div>
        <VideoDisplay isTestSubmitted={isTestSubmitted} />
      </div>
      <div
        style={{
          position: "fixed",
          bottom: 0,
          right: 0,
          margin: "20px",
          maxWidth: "300px",
          maxHeight: "1000px",
        }}
      >
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          style={{ width: "100%", maxWidth: "600px" }}
        />
      </div>
      <button
        className="start-button"
        disabled={
          !isAgreed ||
          cameraPermission !== "granted" ||
          microphonePermission !== "granted" ||
          locationPermission !== "granted"
        }
        onClick={allSectionsHandler}
      >
        Start test
      </button>
    </div>
  );
};

export default InstructionsAccess;
