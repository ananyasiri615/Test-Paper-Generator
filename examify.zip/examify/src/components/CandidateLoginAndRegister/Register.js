import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./CandidateRegister.css";
import signin from "../Candidate/images/signup-image.jpg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUser,
  faLock,
  faUnlock,
  faPerson,
  faMobile,
  faEnvelope,
} from "@fortawesome/free-solid-svg-icons";

const Register = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNo, setPhoneNo] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [registrationStatus, setRegistrationStatus] = useState("");

  const [nameError, setNameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [phoneNoError, setPhoneNoError] = useState("");
  const [usernameError, setUsernameError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [agreedError, setAgreedError] = useState("");
  const [errorr, setErrorr] = useState("");

  const navigate = useNavigate();

  const isEmailValid = (email) => {
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    return emailRegex.test(email);
  };

  const isPasswordValid = (password) => {
    const passwordRegex =
      /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&!_+=-]).{8,}$/;
    return passwordRegex.test(password);
  };

  const isPhoneNoValid = (phoneNo) => {
    const phoneNoRegex = /^\d{10}$/;
    return phoneNoRegex.test(phoneNo);
  };

  const isNameValid = (name) => {
    return name.trim() !== "";
  };

  const isUsernameValid = (username) => {
    return username.trim() !== "";
  };

  const validateForm = () => {
    let valid = true;

    if (
      !isEmailValid(email) &&
      !isPasswordValid(password) &&
      !isPhoneNoValid(phoneNo) &&
      !isNameValid(name) &&
      !isUsernameValid(username)
    ) {
      setErrorr("All the fields are required");
      valid = false;
    }
    else{
      setErrorr("");
    

    if (!isEmailValid(email)) {
      setEmailError("Invalid email");
      valid = false;
    } else {
      setEmailError("");
    }

    if (!isPasswordValid(password)) {
      setPasswordError("Invalid password");
      valid = false;
    } else {
      setPasswordError("");
    }

    if (!isPhoneNoValid(phoneNo)) {
      setPhoneNoError("Invalid phone number");
      valid = false;
    } else {
      setPhoneNoError("");
    }

    if (!isNameValid(name)) {
      setNameError("Name cannot be empty");
      valid = false;
    } else {
      setNameError("");
    }

    if (!isUsernameValid(username)) {
      setUsernameError("Username cannot be empty");
      valid = false;
    } else {
      setUsernameError("");
    }

  }
    return valid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const isFormValid = validateForm();

    if (!isFormValid) {
      return;
    }

    try {
      const response = await fetch("http://localhost:8081/candidates/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, email, phoneNo, username, password }),
      });

      if (response.ok) {
        setRegistrationStatus("Registration successful");
        navigate("/Login");
      } else {
        setRegistrationStatus("Error Occurred");
      }
    } catch (error) {
      console.error("Error:", error);
      setRegistrationStatus("Error Occurred");
    }
  };

  return (
    <div className="main">
      <section className="signup">
        <div
          className="containerr"
          style={{ background: "white", marginBottom: 0 }}
        >
          <div className="signup-content">
            <div className="signup-form">
              <h2 className="form-title">Sign up</h2>
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="name" className="label">
                    <FontAwesomeIcon icon={faPerson} />
                  </label>
                  <input
                    className="input"
                    type="text"
                    name="name"
                    id="name"
                    placeholder="Your Name"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      setNameError("");
                    }}
                  />
                  {nameError && <p>{nameError}</p>}
                </div>
                <div className="form-group">
                  <label htmlFor="username" className="label">
                    <FontAwesomeIcon icon={faUser} />
                  </label>
                  <input
                    className="input"
                    type="text"
                    name="username"
                    id="username"
                    placeholder="username"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      setUsernameError("");
                    }}
                  />
                  {usernameError && <p>{usernameError}</p>}
                </div>
                <div className="form-group">
                  <label htmlFor="phoneNumber" className="label">
                    <FontAwesomeIcon icon={faMobile} />
                  </label>
                  <input
                    className="input"
                    type="number"
                    name="phoneNumber"
                    id="phoneNumber"
                    placeholder="phoneNumber"
                    value={phoneNo}
                    onChange={(e) => {
                      setPhoneNo(e.target.value);
                      setPhoneNoError("");
                    }}
                  />
                  {phoneNoError && <p>{phoneNoError}</p>}
                </div>
                <div className="form-group">
                  <label htmlFor="email" className="label">
                    <FontAwesomeIcon icon={faEnvelope} />
                  </label>
                  <input
                    className="input"
                    type="email"
                    name="email"
                    id="email"
                    placeholder="Your Email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setEmailError("");
                    }}
                  />
                  {emailError && <p>{emailError}</p>}
                </div>
                <div className="form-group">
                  <label htmlFor="password" className="label">
                    <FontAwesomeIcon icon={faLock} />
                  </label>
                  <input
                    className="input"
                    type="password"
                    name="pass"
                    id="pass"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setPasswordError("");
                    }}
                  />
                  {passwordError && <p>{passwordError}</p>}
                </div>
                <div className="form-group">
                  <label htmlFor="re-pass" className="label">
                    <FontAwesomeIcon icon={faUnlock} />
                  </label>
                  <input
                    className="input"
                    type="password"
                    name="re_pass"
                    id="re_pass"
                    placeholder="Repeat your password"
                  />
                </div>
                {errorr && <p>{errorr}</p>}
                <div className="form-group form-button">
                  <button type="submit" className="form-submit">
                    Register
                  </button>
                </div>
              </form>
            </div>
            <div className="signup-image">
              <figure>
                <img src={signin} alt="sign up image" />
              </figure>
              <a href="/Login" className="signup-image-link">
                I am already a member
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Register;
