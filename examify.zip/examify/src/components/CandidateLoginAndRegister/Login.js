import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import authService from "../../services/auth.service.js";
import "./CandidateLogin.css";
import signin from "../Candidate/images/signup-image.jpg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser, faLock } from "@fortawesome/free-solid-svg-icons";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [login, setLogin] = useState(false);

  const [error, setError] = useState(""); 

  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    setError("");

    if (!username || !password) {
      setError("Username and password are required.");
      return;
    }

    try {
      const response = await authService.login(username, password);

      if (response.jwt) {
        navigate("/WelcomePage");
        window.location.reload();
        setLogin(true);
        localStorage.setItem("username", username);
      } else {
        setError("Invalid username or password.");
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="main">
      <section className="sign-in">
        <div
          className="container"
          style={{ background: "white", border: "none" }}
        >
          <div className="signin-content">
            <div className="signin-image">
              <figure>
                <img src={signin} alt="sign up image" />
              </figure>
              <a href="/Register" className="signup-image-link">
                Create an account
              </a>
            </div>

            <div className="signin-form">
              <h2 className="form-title">Candidate Login</h2>
              <form
                method="POST"
                className="register-form"
                id="login-form"
                onSubmit={handleLogin}
              >
                <div className="form-group">
                  <label htmlFor="username" className="label">
                    <FontAwesomeIcon icon={faUser} />
                  </label>
                  <input
                    className="input"
                    type="text"
                    name="username"
                    id="username"
                    placeholder="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="passowrd" className="label">
                    <FontAwesomeIcon icon={faLock} />
                  </label>
                  <input
                    className="input"
                    type="password"
                    name="password"
                    id="password"
                    placeholder="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <div className="form-group form-button">
                  <input
                    type="submit"
                    name="signin"
                    id="signin"
                    className="form-submit"
                    value="Log in"
                    
                  />
                </div>
              </form>
              {error && <div className="error-message">{error}</div>}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Login;
